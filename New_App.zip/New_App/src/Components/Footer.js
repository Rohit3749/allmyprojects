import React from 'react'

export default function Footer() {
  return (
    <>
        <div className="container-fluid">
        <div className="row bg-dark">
            <div className="col-12 text-center text-light fw-bold">&#169; NewsApp | All Rights Reserved</div>
        </div>
        </div>
    </>
  )
}
