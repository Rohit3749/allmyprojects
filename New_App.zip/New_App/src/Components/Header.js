import React, { useState } from 'react'
import {Link, useNavigate} from 'react-router-dom';

export default function Header() {
  const [query, setQuery]= useState("");
  const navigate = useNavigate();
  const handleSearch = (e) => {
    e.preventDefault();
    if (query!== '') {
      navigate(`/search/${query}`);
    }
  }
  return (
    <>
        <nav className="navbar text-light fixed-top navbar-expand-lg bg-success">
  <div className="container-fluid">
    <Link className="navbar-brand text-light" to="/">News King</Link>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/international">International</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/national">National</Link>
        </li> <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/politics">Politics</Link>
        </li> <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/sports">Sports</Link>
        </li> <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/entertainment">Entertainment</Link>
        </li> <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/technology">Technology</Link>
        </li> <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/business">Business</Link>
        </li>
         <li className="nav-item">
          <Link className="nav-link active text-light fw-bold" aria-current="page" to="./search/economy">Economy</Link>
        </li>
      </ul>
      <form onSubmit={(e)=>handleSearch(e)} className="d-flex" role="search">
        <input className="form-control me-2" onChange={(e)=>setQuery(e.target.value)} type="search" placeholder="Search" aria-label="Search"/>
        <button className="btn btn-outline-dark bg-warning" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
    </>
  )
}
