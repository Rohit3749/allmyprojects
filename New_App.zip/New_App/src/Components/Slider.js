import React from 'react'

export default function Slider() {
  return (
    <div>Slider</div>
  )
}
