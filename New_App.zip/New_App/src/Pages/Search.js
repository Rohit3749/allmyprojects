import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';
import LoadingImg from '../img/load.gif';

export default function Search() {
    const [data, setData]=useState([]);
    const {query}=useParams();
    const [loading, setLoading] = useState(true);
const fetchNews=async ()=>{
  const response=await axios.post("http://eventregistry.org/api/v1/article/getArticles",{apiKey:"18231f65-f04c-4d5b-ae63-c511bacc3da7",keyword: query, lang: "hin", articlesCount: 10});
  setLoading(false);
  setData(response.data.articles.results);
}
useEffect(()=>{
  fetchNews();
  setLoading(true);
},[query]);

  return (
   <>
   <div className="container mb-3" style={{marginTop:"100px"}}>
        <div className="row">
        <div className="col-12 text-center">
            <h4 className='text-dark h3 fw-bold' style={{textShadow:"-2px 0px 0px orange"}}>Showing Results for : "{query}"</h4>
            <hr />
        </div>
        {
            data.length > 0 ?
            !loading ? data.map((article, index) => {
                return(
                    <div className="col-12 col-md-3 my-2" key={index}>
              <Link to={`../news/${article.uri}`}>
                    <div className="card p-2">
                        <div className="row">
                            <div className="col-12 ">
                                <img src={article.image} alt="" className='img-fluid w-100' style={{height: 180}}/>
                            </div>
                            <div className="col-12 my-2 ">
                                <h5 className="h6 fw-bold ">{article.title.substr(0, 60)}...</h5>
                                <p><small>BY : <span className='text-danger'>{article.source.title}</span> <br /> On : <span className='text-muted'>{article.date}</span></small></p>
                            </div>
                        </div>
                    </div>
              </Link>
            </div>
                )
            })
            :
            <div className="col-12 text-center">
            <img src={LoadingImg} alt="loader" className='loader-img' /><br />
            Loading... Please wait
            </div>
            :
            <div className="col-12 text-center text-danger">
                Nothing Found for your search.
            </div>
        }
    
           
        </div>
    </div>
   </> 
 )
}
