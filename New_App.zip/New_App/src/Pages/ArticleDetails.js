import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import LoadImg from '../img/load.gif'
import RightSingleArti from '../Home/RightSingleArti';
import RightContent from '../Home/RightContent';
import LeftContent from '../Home/LeftContent';

export default function ArticleDetails() {
    const [data, setData]=useState([]);
    const [loading, setLoading]=useState(true);
    const {uri}=useParams();
    const headers = {
        'Content-Type': 'application/json',
    }
    const fetchArticleDetails=async ()=>{
        const response=await axios.post(" http://eventregistry.org/api/v1/article/getArticle",{articleUri: uri, apiKey:"18231f65-f04c-4d5b-ae63-c511bacc3da7"},{ headers });
        // console.log(response.data);
        const result=await response.data[uri].info;
        setData(result);
        setLoading(false);
    }
    useEffect(()=>{
        fetchArticleDetails();
    }, [uri]);
  return (
    <div className="container mb-3" style={{marginTop:"100px"}}>
        <div className="row">
            <div className="col-12 col-md-8 my-2">
                <div className="card">
                    <div className="card-body">
                        {!loading ?
                        <>
                            <h3 className='fw-bold'>{data.title}</h3>
                            <img src={data.image} className='my-2 img-fluid' alt={data.title} />
                            <p><small>BY : <span className='fw-bold text-danger'>{data.source["title"]}</span> | Published : <span className='text-muted'>{data.date}</span></small></p>
                            <hr />
                            <p>{data.body}</p>
                        </>
                            :
                            <div className="text-center">
                                <img src={LoadImg} alt="loading" className='loader-img'/>
                                <hr />
                                <span className='text-muted'>Loading...please wite a while</span>
                            </div>
                        }
                    </div>
                </div>
            </div>
            <LeftContent/>
        </div>
    </div>
  )
}
