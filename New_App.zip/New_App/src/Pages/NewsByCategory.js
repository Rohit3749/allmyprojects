import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom';

export default function NewsByCategory() {
    const [Headlines, setHeadlines]=useState([]);
    const {uri}=useParams();
const fetchHeadlines=async ()=>{
  const response=await axios.post("http://eventregistry.org/api/v1/article/getArticles",{apiKey:"18231f65-f04c-4d5b-ae63-c511bacc3da7",uri,});
  setHeadlines(response.data.articles.results);
}
useEffect(()=>{
  fetchHeadlines();
},[uri]);
  return (
   <>
    <div className="container my-5">
        <div className="row">
        {
            Headlines.map((article,index)=>{
                return (
                    <div className="col-4">
                    <Link to={`./news/${article.uri}`}>
                       <div className="card p-2">
                    <div className="row">
                        <div className="col-12">
                            <img src={article.image} alt="" className='img-fluid' />
                        </div>
                        <div className="col-12">
                            <h5 className='h5' style={{textDecoration:'none'}}>{article.title.substr(0, 20)}...</h5>
                            <p><small>BY : <span className='text-danger'>{article.source.title}</span> | On : <span className='text-muted'>{article.date}</span></small></p>
                        </div>
                       </div>
                       </div>
                    </Link>
                
            </div>
                )
            })
        }
          
        </div>
    </div>
   </> 
 )
}
