import React from 'react'
import '../App.css'
import { Link } from 'react-router-dom'


export default function LeftSingleArti(props) {
  return (
    <>
        <div className="row">
                  <div className="col-12">
                   <Link to={`./news/${props.uri}`} className='text-title' >
                    <div className="row">
                      <div className="col-4">
                        <img src={props.img} alt="" className='img-fluid w-60 h-60' />
                      </div>
                      <div className="col-8">
                        <h6 className='h6'>{props.headling}</h6>
                      </div>
                      <div className="col-12 ms-5">
                      <p><small>BY : <span className='text-danger'>{props.source}</span> <br /> On <span className='text-muted'>{props.date}</span></small></p>
                      </div>
                      <hr />
                    </div>
                   </Link>
                    
                  </div>
                </div>
    </>
  )
}