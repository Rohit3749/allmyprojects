import React from 'react'

export default function MainHeadling() {
  return (
    <div>MainHeadling</div>
  )
}
