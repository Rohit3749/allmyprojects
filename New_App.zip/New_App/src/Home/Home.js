import React from "react";
import "./../App.css";
import LeftContent from "./LeftContent";
import LeftSingleArti from "./LeftSingleArti";
import RightSingleArti from "./RightSingleArti";
import RightContent from "./RightContent";

export default function Home() {
  return (
    <>
      <div className="container mb-3" style={{marginTop:"100px"}}>
        <div className="row">
        <div className="col-12">
        <marquee scrollamount="7" direction="left"> SENSES 61836.88 <span style={{color:"green"}}>(0.12%)</span> | Nifty 18316.4 <span style={{color:"green"}}>(0.28%)</span> | Nifty Bank 43338.8 <span style={{color:"green"}}>(0.33%)</span> | Nifty Financial Services Kotak Mah. Bank 1957.95 <span style={{color:"green"}}>(0.19%)</span> | Larsen & Toubro 2358.85 <span style={{color:'red'}}>(-0.65%)</span> | M & M 1247.10 <span style={{color:"green"}}>(0.13%)</span> | Maruti Suzuki 9164.85 <span style={{color:"green"}}>(0.58%)</span> | Nestle India 22005.00 <span style={{color:"green"}}>(0.15%)</span> | NTPC 177.05 <span style={{color:"green"}}>(0.60%)</span> | O N G C 167.05 <span style={{color:"green"}}>(1.09%)</span>| Power Grid Corpn 247.60 <span style={{color:"green"}}>(1.27%)</span> | Reliance Industr 2496.60 <span style={{color:"green"}}>(0.69%)</span> | SBI Life Insuran 1188.95 <span style={{color:"green"}}>(0.49%)</span> | St Bk of India 571.90 <span style={{color:'red'}}>(-0.28%)</span> | Sun Pharma.Inds. 953.95 <span style={{color:'red'}}>(-0.37%)</span> | Tata Consumer 790.90 <span style={{color:"green"}}>(0.24%)</span> | Tata Motors 508.15 <span style={{color:"green"}}>(0.89%)</span> | Tata Steel 109.20 <span style={{color:'red'}}>(-0.32%)</span> | TCS 3288.95 <span style={{color:"green"}}>(0.17%)</span> | Tech Mahindra 1046.00 <span style={{color:'red'}}>(-0.17%)</span> | Titan Company 2745.90 <span style={{color:'red'}}>(-0.09%)</span> | UltraTech Cem. 7744.95 <span style={{color:"green"}}>(0.37%)</span> | UPL 680.80 <span style={{color:'red'}}>(-1.96%)</span> | Wipro 383.85 <span style={{color:"green"}}>(0.41%)</span></marquee><span></span>
        </div>
          <div className="col-12 col-md-8 my-2">
            <div className="row">
              <div className="col-12">
              <RightContent/>
              </div>
            </div>
                <RightSingleArti/>
          </div>
         
             <LeftContent/>
              <div className="card-body">
                <LeftSingleArti/>
              </div>
            </div>
          </div>
    </>
  );
}
