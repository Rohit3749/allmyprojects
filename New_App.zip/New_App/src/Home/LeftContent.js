import axios from 'axios';
import React, { useEffect, useState } from 'react'
import Loadimg from '../img/load.gif';
import LeftSingleArti from './LeftSingleArti';


export default function LeftContent() {
const [subHeadlines, setsubHeadlines]=useState([]);
const [loading, setLoading]=useState(true);
const fetchSubHeadlines=async ()=>{
  const response=await axios.post("http://eventregistry.org/api/v1/article/getArticles",{apiKey:"18231f65-f04c-4d5b-ae63-c511bacc3da7",keyword:'economy',lang:'hin',articlesCount:15});
  console.log(response.data);
  setLoading(false);
  setsubHeadlines(response.data.articles.results);
}
useEffect(()=>{
  fetchSubHeadlines();
},[]);

  return (
    <>
    <div className="col-12 col-md-4 my-2">
      <div className="card">
      <div className="card-header  bg-warning text-dark fw-bold">Top News Headlines </div>
      <div className="card-body">
        <div className="row">
        { 
                    subHeadlines.map((article,index)=>{
                      return(
                        <LeftSingleArti key={index} source={article.source.title} date={article.date} uri={article.uri} img={article.image} headling={article.title}/>
                      )
                    })
                  }
        </div>
      </div>
      </div>
    </div>
    </>
    )
}
