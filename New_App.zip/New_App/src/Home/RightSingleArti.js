import React from 'react'
import { Link } from 'react-router-dom'

export default function RightSingleArti(props) {
  return (
    <>
        <div className="row">
                  <div className="col-12 my-2" style={{textDecoration:'none'}}>
                   <Link to={`../news/${props.uri}`}>
                    <div className="row" style={{borderBottom:"1px solid #CCC"}}>
                      <div className="col-4">
                        <img src={props.img} alt="" className='img-fluid w-100 h-75' />
                      </div>
                      <div className="col-8">
                        <h4 className='h6 fw-bold' style={{textDecoration:'none'}}>{props.headling}</h4>
                        <p><small>Source : <span className='text-danger'>{props.source}</span><br />Published : <span className='text-muted'>{props.date}</span></small></p>
                      </div>
                    </div>
                   </Link>
                    
                  </div>
                </div>
    </>
  )
}
