import axios from "axios";
import React, { useEffect, useState } from "react";
// import Loadimg from '../img/load.gif';
import MainHeadlineSingleItem from "./MainHeadlingSingleItem";
import RightSingleArti from "./RightSingleArti";
import Slider from 'react-slick'
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export default function RightContent() {
  const [data, setData] = useState([]);
  const [subHeadlines, setsubHeadlines] = useState([]);
  const [loading, setLoading] = useState(true);
  const fetchMainHeadlines = async () => {
    const response = await axios.post(
      "http://eventregistry.org/api/v1/article/getArticles",
      {
        apiKey: "18231f65-f04c-4d5b-ae63-c511bacc3da7",
        keyword: "breaking",
        lang: "hin",
        articlesCount: 8,
      }
    );
    console.log(response.data);
    setLoading(false);
    setData(response.data.articles.results);
  };
  const fetchSubHeadlines = async () => {
    const response = await axios.post(
      "http://eventregistry.org/api/v1/article/getArticles",
      {
        apiKey: "18231f65-f04c-4d5b-ae63-c511bacc3da7",
        keyword: "india",
        lang: "hin",
        articlesCount: 10,
      }
    );
    setLoading(false);
    setsubHeadlines(response.data.articles.results);
  };
  useEffect(() => {
    fetchMainHeadlines();
    fetchSubHeadlines();
  }, []);

  //npm install slick-carousel
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 1500,
    centerMode: false,
    slidesToShow: 2,
    slidesToScroll: 2
  };

  return (
    <>
      <div className="card">
        <div className="card-header bg-dark text-warning fw-bold">
          Breaking News
        </div>
        <div className="card-body">
          <Slider className="row" {...settings}>
            {data.map((article, index) => {
              return (
                <MainHeadlineSingleItem
                  key={index}
                  source={article.source.title}
                  date={article.date}
                  uri={article.uri}
                  img={article.image}
                  headling={article.title}
                />
              );
            })}
          </Slider>
        </div>
      </div>
      <div className="col-12 mt-3">
        <div className="card">
          <div className="card-body">
            {subHeadlines.map((article, index) => {
              return (
                <RightSingleArti
                  key={index}
                  source={article.source.title}
                  date={article.date}
                  uri={article.uri}
                  img={article.image}
                  headling={article.title}
                />
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
}
