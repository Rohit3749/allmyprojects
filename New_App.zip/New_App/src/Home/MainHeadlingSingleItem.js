import React from 'react'
import { Link } from 'react-router-dom'

export default function MainHeadlineSingleItem(props) {
  return (
    <div className="col-12 col-md-12 p-1" style={{textDecoration:'none'}}>
        <Link to={`news/${props.uri}`}>
            <img src={props.img} alt="" className='breaking_news_img img-fluid' />
            <h5 className='news_headling mt-2'>{props.headling}</h5>
            <p><small><span className='text-danger'>{props.source}</span> | <span className='text-muted'>Published : {props.date}</span> </small></p>
        </Link>
    </div>
  )
}
