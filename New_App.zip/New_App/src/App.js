import './App.css';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Header from './Components/Header';
import Footer from './Components/Footer';
import Home from './Home/Home';
import ArticleDetails from './Pages/ArticleDetails';
import NewsByCategory from './Pages/NewsByCategory';
import Search from './Pages/Search';

function App() {
  return (
   <>
    <BrowserRouter>
    <Header/>
    <Routes>
    <Route path='*' element={<Home/>}/>
    <Route path='/news/:uri' element={<ArticleDetails/>}/>
    <Route path='/articies/:uri' element={<NewsByCategory/>}/>
    <Route path='/search/:query' element={<Search/>}/>
    </Routes>
    <Footer/>
    </BrowserRouter>
   </>
  );
}

export default App;
