import React, { useState } from "react";
import '../COmponents/NewFrend.css'
import {useNavigate} from 'react-router-dom'
import axios from 'axios'

const initialState={
  friendname:"",
  gender:"",
  address:"",
  contactno:"",
  emailaddress:""
}

export default function NewFriend() {
  const [state,setState]=useState(initialState);
  const [photo,setPhoto]=useState();
  const {friendname,gender,address,contactno,emailaddress}=state;
  const navigate=useNavigate();

  const handleInput=(e)=>{
    const {name,value}=e.target;
    setState({...state,[name]:value});
  }
  const handleFile=(e)=>{
    var reader=new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload=()=>{
      setPhoto(reader.result);
    }
  }
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:5000/api/friends",{friendname,gender,address,contactno,emailaddress,photo})
    .then(()=>{
      setState({friendname:"",gender:"",address:"",contactno:"",contactno:"",emailaddress:""});
      setPhoto({photo:""});
    }).catch((error)=>{
      console.log(error);
    })
    navigate("/");
  }
  return (
    <div className="Form-Add">
      <h2 style={{ textAlign: "center" }}>Add New Friend</h2>
      <form onSubmit={handleSubmit} >
        <table style={{ margin: "0 auto", width: "50%" }}>
          <tr>
            <td><h4> Enter Name</h4></td>
            <td>
              <input type="text" name="friendname" required className="inptext" onChange={handleInput} />
            </td>
          </tr>
          <tr>
            <td><h5>Select Gender</h5></td>
            <td style={{fontSize:'25px',}}>
              <input type="radio" name="gender" value="Male" style={{marginLeft:'20px'}} onChange={handleInput}/>Male
              <input type="radio" name="gender" value="Female" style={{marginLeft:'20px'}} onChange={handleInput}/>Female
            </td>
          </tr>
          <tr>
            <td><h5>Enter Address</h5> </td>
            <td>
              <textarea name="address" cols="30" rows="3" className="inptext" onChange={handleInput} ></textarea>
            </td>
          </tr>
          <tr>
            <td><h5> Enter Contact Number</h5></td>
            <td><input type="number" name="contactno" required className="inptext" onChange={handleInput}/></td>
          </tr>
          <tr>
            <td><h5> Enter Email Address</h5></td>
            <td>
              <input type="email" name="emailaddress" required className="inptext" onChange={handleInput} />
            </td>
          </tr>
          <tr>
            <td><h5> Select Pic</h5></td>
            <td>
              <input type="file" accept="image/" name="photo" onChange={handleFile} />
            </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>
              <input type="submit" className="btn" value="save" />
            </td>
          </tr>
        </table>
      </form>
    </div>
  );
}
