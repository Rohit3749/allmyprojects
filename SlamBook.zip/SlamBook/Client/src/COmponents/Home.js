import React, {useEffect,useState} from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

function Home() {
  const [data,setData]=useState([]);
  const loadData=async()=>{
    const response=await axios.get("http://localhost:5000/api/friends");
    setData(response.data);
  }
  useEffect(()=>{
    loadData();
  },[]);
  const deleteslam=(id)=>{
    if(window.confirm("Are you sure?")){
        axios.delete(`http://localhost:5000/api/friends/${id}`);
        setTimeout(()=>loadData(),500);
    }
}
  return (
    <div>
        <h2 style={{textAlign:"center"}}>My Friend List</h2>
        <p style={{textAlign:"center"}}>
            <Link to="/newfriend">Add New Friend</Link>
        </p>
        <table border='1' style={{margin:'0 auto',width:'90%',marginTop:'20px',boxShadow: 'rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px'}}>
        <thead style={{textAlign:'center',color:'Black', fontSize:'20px',fontWeight:'700',backgroundColor:'yellowgreen'}}>
          <tr>
            <th>Name</th>
            <th>Gender</th>
            <th>Address</th>
            <th>Contact No</th>
            <th>Email Address</th>
            <th>Photo</th>
            <th>Delete</th>
          </tr>
        </thead>
    <tbody style={{textAlign:'center',color:'red', fontSize:'20px',fontWeight:'700'}}>
      {
        data.map((value,index)=>{
          return(
          <tr key={value._id}>
            <td>{value.friendname}</td>
            <td>{value.gender}</td>
            <td>{value.address}</td>
            <td>{value.contactno}</td>
            <td>{value.emailaddress}</td>
            <td>
              <img src={value.photo} width="100" height="100" />
            </td>
            <td><button className='btn btn-danger' onClick={()=>deleteslam(value._id)}>Delete</button></td>

          </tr>
          )
        })
      }
    </tbody>
        </table>
    </div>
  )
}

export default Home