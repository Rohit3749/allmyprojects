import './App.css';
import {BrowserRouter ,Routes,Route} from "react-router-dom"
import Home from './COmponents/Home';
import NewFriend from './COmponents/NewFriend';

function App() {
  return (
    <>
    <BrowserRouter>
   <Routes>
    <Route index element={<Home/>}/>
    <Route path='newfriend' element={<NewFriend/>}/>
   </Routes>
   </BrowserRouter>
   </>
  );
}

export default App;
