const SlamBook=require("../model/SlamBook");

const friend_all=async (req,res)=>{
    try{
    const friends=await SlamBook.find();
    res.json(friends);
}catch(error){
    res.json({message:error});
}
};
const friend_create=async (req,res)=>{
    const friend=new SlamBook({
        friendname:req.body.friendname,
        gender:req.body.gender,
        address:req.body.address,
        contactno:req.body.contactno,
        emailaddress:req.body.emailaddress,
        photo:req.body.photo
    });
    try{
        const saveFriend=await friend.save();
        res.send(saveFriend);
    }catch(error){
        console.log(error);
    }
}
const friend_delete=async (req,res)=>{
    try{
    const removeFriend=await SlamBook.findByIdAndDelete(req.params.friendId);
    response.json(removeFriend);
    }
    catch(error){
        console.log(error);
    }
}
module.exports={
    friend_all,
    friend_create,
    friend_delete
}