const router=require("express").Router();
const slambookController=require("../controller/SlamBookController")
router.get("/",slambookController.friend_all);
router.post("/",slambookController.friend_create);
router.delete("/:friendId",slambookController.friend_delete);
module.exports=router;