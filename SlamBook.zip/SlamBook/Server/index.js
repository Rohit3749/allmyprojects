var express=require("express");
var bodyParser=require("body-parser");
var mongoose=require("mongoose");
var cors=require("cors");
var friendRouter=require("./route/route");

var app=express();
app.use(express.json({
    limit:'5mb'
}));
app.use(cors());
app.use(bodyParser.urlencoded({extended:true,limit:'5mb'}));

mongoose.connect("mongodb://127.0.0.1:27017/slambook")
.then(()=>{
    console.log("Database is Connected");
}).catch((error)=>{
    console.log(error);
});
app.listen(5000,()=>{
    console.log("Server is running at port 5000");
});
app.use("/api/friends/",friendRouter);