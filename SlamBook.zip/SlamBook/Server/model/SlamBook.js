var mongoose=require("mongoose");
const SlamBookSchema=new mongoose.Schema({
    friendname:String,
    gender:String,
    address:String,
    contactno:String,
    emailaddress:String,
    photo:String
});
module.exports=mongoose.model("SlamBook",SlamBookSchema);