import React from 'react'
import './About.css';
import Rohit from '../img/rohit.png.jpg'

function AboutUs() {
  return (
    <>
    <section className='hero'>
      <div className="heading">
        <h1>About Us</h1>
      </div>
      <div className="contai">
        <div className="hero-content">
          <h3>Developer & Designer </h3>
          <p>I am a MERN Stack developer. I can provide clean code and pixel perfect design . I also make the website more & more interactive with web application. I can provide clean code pixel perfect design. I also make the website more & more interactive with React application.</p>
          <button className='btn-button'>Learn More</button>
        </div>
        <div className="hero-image">
        <img src={Rohit} alt='' />
        </div>
      </div>
    </section>
    </>
  );
}

export default AboutUs