import React from 'react'
import '../index.css';
// import Rohit from '../img/rohit.jpg';
import './Contact.css';
import RohitFile from '../img/Rohit1.pdf';
import AboutUs from './AboutUs';
import ProjectDetails from './ProjectDetails';
import { Link } from 'react-router-dom';
import Skills from './Skills';
import ContactUs from './ContactUs';
function Home() {
  return (
    <>





    <div id="carouselExampleIndicators" className="carousel slide">
  <div className="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
   </div>
  <div className="carousel-inner">
    <div className="carousel-item active">
    <div className="row home ">
    <div className='col-7 text-run'>
        <h1>Hey, I'm <span style={{color:'#f4065d'}}> Rohit Kumar </span><br />,a Designer MERN Stack <br /> 1 Years of experince</h1>
        <p className='text-text'>I care a lot about using design for positive impact <br />and enjoy creating user-centric, delightful, and hum experiences</p>
        <button className='butt-cv'> <Link to={RohitFile} download="CV Download" >CV Download
        </Link>
        </button>
      
        </div>
        <div className='col-4 pt-5 my-5 align-center'>
        <div className="crecal text-run "></div>
        </div>
      </div>
    </div>
  </div>
  
</div>
 <AboutUs/>
 <Skills/>
<ProjectDetails/>
<ContactUs/>
    </>
  );
}

export default Home