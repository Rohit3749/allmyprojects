import React from 'react'
import { FaFacebook,} from "react-icons/fa";
import { BsFillEnvelopeAtFill } from "react-icons/bs";
import {  BsInstagram,BsWhatsapp } from "react-icons/bs";
import { AiFillTwitterCircle } from "react-icons/ai";
import { Link } from 'react-router-dom';
import './Footer.css'

export default function Footer() {
  return (
    <>
        <footer className="bg-dark text-white pt-5 pb-4">
        <div className="container text-center text-md-left">
            <div className="row text-center text-md-left">
                <div className="col-md-3 col-lg-3 col-xl-3 mx-auto  mt-3">
                    <h5 className="text-uppercase mb-4 font-weight-bold ">ROHIT KUMAR</h5>
                    <p>I AM Design and Develop MERN Stack</p>
                </div>
                <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                    <h5 className="text-uppercase mb-4 font-weight-bold ">PAGES</h5>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>Home</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>About Us</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>Skills</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>Project Details</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>Contact Us</Link></p>
                </div>
                <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                    <h5 className="text-uppercase mb-4 font-weight-bold ">Application</h5>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>This Application</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>Your Application</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>My Application</Link></p>
                    <p><Link className="text-white" style={{textDecoration:'none'}}>He Application</Link></p>
                </div>
                <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3" >
                    <h5 className="text-uppercase mb-4 font-weight-bold ">Contact Us</h5>
                    <p><i >  Siwan Bihar (841245)</i></p>
                    <p><i >  kumarkumarrohit3749@gmial.com</i></p>
                    <p><i >  +91 7255906980</i></p>
                    <p><i >  +91 7519851511</i></p>
                </div>
            </div>
            <hr className="mb-4"/>
            <div className="row align-item-center">
                <div className="col-md-2 col-lg-5">
                    <p>Copyright &#169;2023 All right reserved by: 
                        <Link to='/' style={{textDecoration:'none'}}><strong className="text-warning">Rohit Kumar</strong></Link>
                    </p>
                </div>
                <div className="col-md-5 col-lg-6">
                    <div className="text-center text-md-right">
                        <ul className="list-unstyled list-inline">
                            <li className="list-inline-item">
                            <i>  <Link to='/facebook' ><FaFacebook/></Link></i>
                            </li>
                            <li className="list-inline-item">
                            <i>  <Link to='/instagram'><BsInstagram/></Link></i>
                            </li><li className="list-inline-item">
                            <i> <Link to='/twitter'><AiFillTwitterCircle/></Link></i>
                            </li><li className="list-inline-item">
                            <i>   <Link to='/email'><BsFillEnvelopeAtFill/></Link></i>
                            </li>
                            <li className="list-inline-item">
                            <i>  <Link to='/whatsapp'><BsWhatsapp/></Link></i>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    </>
  )
}
