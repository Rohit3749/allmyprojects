import React from 'react'
import './Contact.css';
import { Link } from 'react-router-dom';

function ContactUs() {
  return (
    <> 
     <div className="contain">
     
     <div className="form">
       <div className="contact-info">
         <h3 className="title">Reach Us</h3>
         <div className="info">
           <div className="information">
             <p>101 Panday Market Jamapur, Jiradei Siwan (Bihar)</p>
           </div>
           <div className="information">
             <p>kumarkumarrohit3749@gmail.com</p>
           </div>
           <div className="information">
            
             <p>+91-7255906980</p>
           </div>
         </div>

         <div className="social-media">
           <p>Connect with us :</p>
           <div className="social-icons">
             <Link to="#">
               <i className="fab fa-facebook-f"></i>
             </Link>
             <Link to="#">
               <i className="fab fa-twitter"></i>
             </Link>
             <Link to="#">
               <i className="fab fa-instagram"></i>
             </Link>
             <Link to="#">
               <i className="fab fa-linkedin-in"></i>
             </Link>
           </div>
         </div>
       </div>

       <div className="contact-form">
       <form action="index.html" autocomplete="off">
           <h3 className="title">Send your request</h3>
           <div className="input-container">
             <input type="text" name="name" className="input" />
             <label for="">Username</label>
             <span>Username</span>
           </div>
           <div className="input-container">
             <input type="email" name="email" className="input" />
             <label for="">Email</label>
             <span>Email</span>
           </div>
           <div className="input-container">
             <input type="tel" name="phone" className="input" />
             <label for="">Phone</label>
             <span>Phone</span>
           </div>
           <div className="input-container textarea">
             <textarea name="message" className="input"></textarea>
             <label for="">Message</label>
             <span>Message</span>
           </div>
           <input type="submit" value="Send" className="btn" />
         </form>
       </div>
     </div>
   </div>

    </>
  );
}

export default ContactUs