import React from 'react'
import '../index.css';
import { Link } from 'react-router-dom'
import Logo from '../img/R.png';

function Header() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
    <div className="container-fluid">
      <Link className="navbar-brand " to="/home"><img src={Logo} alt="logo" style={{width:'90px',height:'60px',borderRadius:'50%'}} /></Link>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse  " id="navbarSupportedContent">
        <ul className="navbar-nav ms-auto  mb-2 mb-lg-10 header-hob " style={{fontFamily:'Courier New, Courier, monospace',fontSize:'20px'}}>
          <li className="nav-item">
            <Link className="nav-link active text-fonr" aria-current="page" to="/home">Home</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link active text-fonr" aria-current="page" to="/aboutus">AboutUs</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link active text-fonr" aria-current="page" to="/skills">Skills</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link active text-fonr" aria-current="page" to="/project">Project</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link active text-fonr" aria-current="page" to="/contactus">Contact Us</Link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  )
}

export default Header