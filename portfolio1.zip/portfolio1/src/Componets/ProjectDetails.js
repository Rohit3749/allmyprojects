import React from 'react'
import './Project.css';
import Rohit from '../img/im1.png'
import Rohit1 from '../img/im2.png'
import Rohit2 from '../img/im3.png'
import Rohit3 from '../img/im4.png'
import Rohit4 from '../img/im5.png'
import Rohit5 from '../img/im6.png'
import Rohit6 from '../img/im7.png'
import Rohit7 from '../img/im8.png'
import Rohit8 from '../img/im9.png'
import Rohit9 from '../img/10.png'
import Rohit10 from '../img/im11.png'
import Rohit12 from '../img/im12.png'
import { Link } from 'react-router-dom';
function ProjectDetails() {
  return (
    <>

   {/* services section */}
   <section className="services" id='services'>
   <div className="main-text">
    <h2><span> My </span>Services</h2>
    </div>
    <div className="services-content">
    <div className="box">
        <div className="s-icons">
        {/* <i class="fa-solid fa-mobile-screen-button"></i>               */}
          </div>
        <h3>Web Design </h3>
        <p>One Way to categories the activities is in terms of the professional's area of experience such as cometitive analysis, corporate stragety.</p>
        <Link to="#" className='btn'>Read More</Link>
    </div>
    <div className="box">
        <div className="s-icons">
        {/* <i class="fa-regular fa-code"></i> */}
        </div>
        <h3>Creative Design</h3>
        <p>One Way to categories the activities is in terms of the professional's area of experience such as cometitive analysis, corporate stragety.</p>
        <Link to="#" className='btn'>Read More</Link>
    </div>
    <div className="box">
        <div className="s-icons">
        {/* <i class="fa-solid fa-pen-to-square"></i> */}
                </div>
        <h3>Web Design</h3>
        <p>One Way to categories the activities is in terms of the professional's area of experience such as cometitive analysis, corporate stragety.</p>
        <Link to="#" className='btn'>Read More</Link>
        </div>
    
   </div>
   </section>
   {/* project Details */}
   <section className="portfolio">
    <div className="main">
        <h2><span>Latest</span> Project</h2>
    </div>
    <div className="portfolio-content">
    <div className="row">
            <img src={Rohit12} alt="" />
            <div className="layer">
                <h5>Web Design CRM </h5>
                <p>If a new user come he will redirected to signup page, without signup or login he is not be able to access the rest of the page.</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit} alt="" />
            <div className="layer">
                <h5>Home Page Design</h5>
                <p>He can update , delete, and filter the product based on search</p>
                <Link to="#"><i className='bx bx-link-external '></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit1} alt="" />
            <div className="layer">
                <h5>Add to cart </h5>
                <p>add the product and he will be redirected to add product page</p>
                <Link to="#"><i className='bx bx-link-external '></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit2} alt="" />
            <div className="layer">
                <h5>E-Comm Dashboard</h5>
                <p>This page is fully remote user and client feedback customized Edit and Delete.</p>
                <Link to="#"><i className='bx bx-link-external '></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit3} alt="" />
            <div className="layer">
                <h5>CRUD Functionality</h5>
                <p>It has CRUD or photo upload functionality.</p>
                <Link to="#"><i className='bx bx-link-external '></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit4} alt="" />
            <div className="layer">
                <h5>Add List </h5>
                <p>User Login Pages.</p>
                <Link to="#"><i className='bx bx-link-external '></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit5} alt="" />
            <div className="layer">
                <h5>Clone</h5>
                <p>This page using HTML, CSS page is Design Clone.</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit6} alt="" />
            <div className="layer">
                <h5>Edit and Delete</h5>
                <p>This pages Design is CRED functionality.</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit7} alt="" />
            <div className="layer">
                <h5>Edit Products</h5>
                <p>Edit Products page .</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit8} alt="" />
            <div className="layer">
                <h5>New App</h5>
                <p>News King is a React js app that show interesting news for users.</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit9} alt="" />
            <div className="layer">
                <h5>Pages</h5>
                <p>News Api is third party api that provides news to our News Ling App Categories.</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div>
        <div className="row">
            <img src={Rohit10} alt="" />
            <div className="layer">
                <h5>Doctor Home Pages</h5>
                <p>This page home slider and other functionality.</p>
                <Link to="#"><i class="fa-solid fa-up-right-from-square"></i></Link>
            </div>
        </div> 
      
    </div>
   </section>
    </>
  );
}

export default ProjectDetails