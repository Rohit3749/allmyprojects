import React from 'react'
import { About as Home } from './Home'
import AboutUs from './AboutUs'
import ProjectDetails from './ProjectDetails'
import ContactUs from './ContactUs'

export default function AllFiles() {
  return (
    <>

        <Home/>
        <AboutUs/>
        <ProjectDetails/>
        <ContactUs/>
    </>
  )
}
