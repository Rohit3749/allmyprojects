import {BrowserRouter ,Routes,Route} from "react-router-dom"
import AboutUs from "./Componets/AboutUs";
import Home from "./Componets/Home";
import ContactUs from "./Componets/ContactUs";
import ProjectDetails from "./Componets/ProjectDetails";
import Header from "./Componets/Header";
import Footer from "./Componets/Footer";
import Skills from "./Componets/Skills";
function App() {
  return (
   <BrowserRouter>
   <Header/>
    <Routes>
    <Route index element={<Home/>}/>
    <Route path='home' element={<Home/>}/>
    <Route path='aboutus' element={<AboutUs/>}/>
    <Route path='skills' element={<Skills/>}/>
    <Route path='project' element={<ProjectDetails/>}/>
    <Route path='contactus' element={<ContactUs/>}/>
    </Routes>
    <Footer/>
   </BrowserRouter>
  );
}

export default App;
