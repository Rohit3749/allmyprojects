var express = require("express");
var con = require("./connection");
var bodyParser = require("body-parser");
var cors = require("cors");
var session = require("express-session");
var cookieParser = require("cookie-parser");

var app = express();
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);
app.use(cookieParser());
app.use(
  session({
    key: "userid",
    secret: "myseret",
    resave: true,
    saveUninitialized: true,
    cookie: {
      expires: 60 * 60 * 24 * 1000,
    },
  })
);
app.post("/regcode", function (req, res) {
  var name = req.body.name;
  var gender = req.body.gender;
  var address = req.body.address;
  var contactno = req.body.contactno;
  var emailaddress = req.body.emailaddress;
  var password = req.body.password;
  var usertype = "customer";
  var sql1 =
    "insert into customer values('" +
    name +
    "','" +
    gender +
    "','" +
    address +
    "','" +
    contactno +
    "','" +
    emailaddress +
    "')";
  var sql2 =
    "insert into login values('" +
    emailaddress +
    "','" +
    password +
    "','" +
    usertype +
    "')";
  var response = false;
  con.query(sql1, function (error, result) {
    if (error) {
      console.log(error);
    } else {
      con.query(sql2, function (error, result) {
        if (error) {
          console.log(error);
        }
        res.send("Successfully");
      });
    }
  });
});
app.post("/login", function (req, res) {
  var userid = req.body.userid;
  var password = req.body.password;
  if (!userid || !password) {
    return res.send({
      message: "All Feield are requird",
    });
  }
  var sql =
    "select * from login where userid='" +
    userid +
    "' and password='" +
    password +
    "'";
  con.query(sql, function (error, result) {
    if (error) {
      console.log(error);
    }
    if (result.length > 0) {
      if (result[0].usertype == "customer") {
        req.session.user = result;
        res.send({usertype:'customer'});
      }
      // console.log(req.session.user);
      else if (result[0].usertype=="admin")
      {
        console.log('admin');
        req.session.admin = result
        res.send({usertype:'admin'});
      }
      
    } else {
      res.send({ message: "User Id or Password Not Match" });
    }
  });
});
app.post("/contact", function (req, res) {
  var name = req.body.name;
  var contactno = req.body.contactno;
  var emailaddress = req.body.emailaddress;
  var subject = req.body.subject;
  var message = req.body.message;
  var sql =
    "insert into contact(name,contactno,emailaddress,subject,message) values('" +
    name +
    "','" +
    contactno +
    "','" +
    emailaddress +
    "','" +
    subject +
    "','" +
    message +
    "')";
  con.query(sql, function (error, result) {
    if (error) {
      console.log(error);
    }
    res.send("Successfully");
  });
});
app.get("/login", function (req, res) {
  if (req.session.user) {
    res.send({ loggedin: true, user: req.session.user });
  } else {
    res.send({ loggedin: false });
  }
});
app.post("/savefeedback", function (req, res) {
  var subject = req.body.subject;
  var feedbacktext = req.body.feedbacktext;
  var emailaddress = req.session.user[0].userid;
  var sql1 = "select * from customer where emailaddress='" + emailaddress + "'";
  con.query(sql1, function (error, result) {
    if (error) {
      console.log(error);
    } else {
      var name = result[0].name;
      var contactno = result[0].contactno;
      var sql2 =
        "insert into feedback(name,contactno,subject,feedbacktext) values ('" +
        name +
        "','" +
        contactno +
        "','" +
        subject +
        "','" +
        feedbacktext +
        "')";
      con.query(sql2, function (error, result) {
        if (error) {
          console.log(error);
        }
        res.send("Your Feedback Send Sucessfulley 👍");
      });
    }
  });
});
app.post("/savecomplain", function (req, res) {
  var subject = req.body.subject;
  var complaintext = req.body.complaintext;
  var emailaddress = req.session.user[0].userid;
  var sql1 = "select * from customer where emailaddress='" + emailaddress + "'";
  con.query(sql1, function (error, result) {
    if (error) {
      console.log(error);
    } else {
      var name = result[0].name;
      var contactno = result[0].contactno;
      var sql2 =
        "insert into complain(name,contactno,subject,complaintext) values ('" +
        name +
        "','" +
        contactno +
        "','" +
        subject +
        "','" +
        complaintext +
        "')";
      con.query(sql2, function (error, result) {
        if (error) {
          console.log(error);
        }
        res.send(" Your Complain Send Sucessfulley 👍");
      });
    }
  });
});
app.post("/change", function (req, res) {
  var oldpassword = req.body.oldpassword;
  var newpassword = req.body.newpassword;
  var userid = req.session.user[0].userid;
  var sql =
    "update login set password='" +
    newpassword +
    "' where userid='" +
    userid +
    "' and password='" +
    oldpassword +
    "'";
  con.query(sql, function (error, result) {
    if (error) {
      console.log(error);
    }
    console.log(result);
    if (result.changedRows < 1) {
      return res.send({
        success: false,
        message: "Password does not match",
      });
    }
    res.send({
      success: true,
      message: "Password Changed Successfully",
    });
  });
});
app.post("/add",function(req,res){
  var notificationtext=req.body.notificationtext;
  var date=new Date();
  var posteddate=date.toLocaleDateString();
  var sql="insert into notification(notificationtext, posteddate) values('"+notificationtext+"','"+posteddate+"')";
  con.query(sql,function(error,result){
    if(error){
      console.log(error);
    } else {
      res.send("Success")
    }
  })
})
app.get("/viewnotification",function(req,res){
  var sql="select * from notification";
  con.query(sql, function(error,result){
    if(error){
      console.log(error);
    }
    res.send(result);
  })
})
app.delete("/deletenotification/:id",function(req,res){
  const {id}=req.params;
  var sql="delete from notification where id=?";
  con.query(sql,id,function(error,result){
    if(error){
      console.log(error);
    } else{
      res.send("Deleted")
    }
  })
})
app.get("/viewcustomer",function(req,res){
  var sql="select * from customer";
  con.query(sql,function(error,result){
      if(error){
          console.log(error);
      }
      res.send(result);
})
});
app.delete("/deletecustomer/:email",function(req,res){
  const {email}=req.params;
  var sql1="delete from customer where emailaddress=?";
  var sql2="delete from login where userid=? ";
  con.query(sql1,email,function(error,result){
    if(error){
      console.log(error);
    }
    else{
      con.query(sql2,email,function(error,result){
        if(error){
          console.log(error);
        } else{
          res.send("Deleted")
        }
      })
    }
  })
})
app.get("/viewcomplain",function(req,res){
  var sql="select * from complain";
  con.query(sql,function(error,result){
      if(error){
          console.log(error);
      }
      res.send(result);
})
});
app.delete("/deletecomplain/:id",function(req,res){
  const {id}=req.params;
  var sql="delete from complain where id=?";
  con.query(sql,id,function(error,result){
    if(error){
      console.log(error);
    } else{
      res.send("Deleted")
    }
  })
})
app.get("/viewfeedback",function(req,res){
  var sql="select * from feedback";
  con.query(sql,function(error,result){
      if(error){
          console.log(error);
      }
      res.send(result);
})
});
app.delete("/deletefeedback/:id",function(req,res){
  const {id}=req.params;
  var sql="delete from feedback where id=?";
  con.query(sql,id,function(error,result){
    if(error){
      console.log(error);
    } else{
      res.send("Deleted")
    }
  })
})
app.get("/viewenquiries",function(req,res){
  var sql="select * from contact";
  con.query(sql,function(error,result){
      if(error){
          console.log(error);
      }
      res.send(result);
})
});
app.delete("/deleteenquiries/:id",function(req,res){
  const {id}=req.params;
  var sql="delete from contact where id=?";
  con.query(sql,id,function(error,result){
    if(error){
      console.log(error);
    } else{
      res.send("Deleted")
    }
  })
})
app.use(session({
  key:'adminid',
  secret:'mysecret2',
  resave:true,
  saveUninitialized:false,
  cookie:{
    express:60*60*24,
  }
}));
app.post("/adminpasswordchane",function(req,res){
  var oldpassword=req.body.oldpassword;
  var newpassword=req.body.newpassword;
  var userid=req.session.admin[0].userid;
  var sql="update login set password=? where userid=? and password=?";
  con.query(sql,[newpassword,userid,oldpassword],function(error,result){
    if(error){
      console.log(error);
    }
    res.send("Password Changed");
  })
})
app.get("/viewns",function(req,res){
  var sql="select * from notification";
  con.query(sql,function(error,result){
    if(error){
      console.log(error);
    }
    res.send(result);
  })
})
app.listen(5000);
