import React from 'react'
import Footer from '../comp/Footer';
import CustNavber from './CustNavber';
import { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import toast from "react-hot-toast";

const initialState={
  subject:"",
  complaintext:""
}


function Complain() {
  const [state,setState]=useState(initialState);
  const {subject,complaintext}=state;
  const navigate=useNavigate();
  const handleInput=(e)=>{
    const {name,value}=e.target;
    setState({...state,[name]:value});
  }
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:5000/savecomplain",state)
    .then((response)=>{
      toast.success(response.data)
      setState({name:"",complaintext:""})
    }).catch((err)=>{
      console.log(err);
    });
    setTimeout(()=>navigate("/custzone/custhome"),500)
  }
  return (
    <>
   
   
        <div className="container container-fluid"></div>
      <CustNavber />
      <div>
        <div
          className="container my-5"
          style={{background: 'radial-gradient(circle, rgba(89,246,228,1) 0%, rgba(247,23,84,1) 100%)',borderRadius:'10px 30% 10px 30%',boxShadow: '5px 10px 18px #888888' }}
        >
          <div className="row">
            <form className="form-group" onSubmit={handleSubmit} >
              <div class="col-md-6 offset-md-3">
                <div className="login-form p-5">
                <h2 style={{fontFamily:"cursive",marginBottom:'40px',color:'#f3f6f6'}}>Complain Form</h2>
                  <div className="form-floating mb-3">
                    <input
                      type="text"
                      className="form-control"
                      id="floatingInput"
                      placeholder="Subject"
                      name="subject"
                      onChange={handleInput}
                    />
                    <label for="floatingInput">Enter Subject</label>
                  </div>
                  <div className="form-floating">
                    <input
                      type="text"
                      className="form-control "
                      id="floatingPassword"
                      placeholder="Complaintext"
                      name="complaintext"
                      onChange={handleInput}
                    />
                    <label for="floatingPassword"> Enter Complain</label>
                    <button type="submit" className="btn btn-info mt-3 ">
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

    <Footer />
    </>
  )
}

export default Complain;