import React,{useEffect} from 'react';
import { useNavigate } from 'react-router-dom';

function Logout() {
    const navigate=useNavigate();
    useEffect(()=>{
        setTimeout(()=>navigate('/login'),500);
    })
  return (
    <div>
    <h2>Logout</h2>
    </div>
  )
}

export default Logout;