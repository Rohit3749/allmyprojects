import { Link, } from "react-router-dom";
// import logo from "./../IMG/logo.jpg";
import LogoutIcon from '@mui/icons-material/Logout';
import KeyIcon from '@mui/icons-material/Key';
const CustNavber = () => {
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark  heade" style={{background:'#2c4c54',boxShadow: '0 2px 15px -2px rgba(0,0,0,0.5)'}}>
        <div className="container-fluid ">
        {/* <img
            src={logo}
            className="d-block "
            width="70px"
            height="60px"
            alt="..."
          /> */}
          <h1 style={{color:'lightpink'}}>Customer Zone</h1>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav ms-auto mb-2 mb-lg-0 me-2">
              <li className="nav-item">
                <Link className="nav-link active" to="/custzone/custhome">Home </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/custzone/feedback">
                  Feedback
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/custzone/complain">
                Complain
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/custzone/changepassword">
                 <KeyIcon /> Change Password
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/custzone/logout">
                <LogoutIcon />
                Logout
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>  
    </>
  );
};
export default CustNavber;
