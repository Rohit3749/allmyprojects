import React from "react";
import Footer from "../comp/Footer";
import CustNavber from "./CustNavber";
import "./CustHome.css";
import Sade1 from "./../IMG/sade1.png";
import Home1 from "./../IMG/home1.png";
import Home2 from "./../IMG/home2.png";
import Home3 from "./../IMG/home3.png";
import Home4 from "./../IMG/home4.pnh.jpg";
import axios from "axios";
import { useEffect, useState } from "react";
import UserProfile from "./UserProfile";
import Shop from "./Shop";

function CustHome() {
  return (
    <>
      <div className="container container-fluid"></div>
      <CustNavber />
      <div
        className="row my-2"
        style={{ minHeight: "600px", textAlign: "center" }}
      >
        <h1>{UserProfile.getUserId()}</h1>
        <div
          id="carouselExampleFade"
          className="carousel slide carousel-fade"
          data-bs-ride="carousel"
        >
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img
                src={Home1}
                className="d-block w-100"
                width="80%"
                height="500px"
                alt="..."
              />
              <div className="text-box">
                <h1>Emerging Biotech</h1>
                <p>
                  Develop and commercialize your product with an experienced
                  partner
                </p>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src={Home2}
                className="d-block w-100"
                height="500px"
                alt="..."
              />
              <div className="text-box">
                <h1>Enterprise Commercial Solutions</h1>
                <p>
                  Elevate customer experience across your enterprise and
                  transform your commercial operations
                </p>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src={Home3}
                className="d-block w-100"
                height="500px"
                alt="..."
              />
              <div className="text-box">
                <h1>Medical Devices</h1>
                <p>
                  Make the most of your data to enhance your <br />{" "}
                  competitiveness and elevate customer experience
                </p>
              </div>
            </div>
            <div className="carousel-item">
              <img
                src={Home4}
                className="d-block w-100"
                height="500px"
                alt="..."
              />
              <div className="text-box1">
                <h1>Enterprise Clinical Solutions</h1>
                <p>
                  Accelerate clinical trials to bring innovative therapies to
                  patients faster
                </p>
              </div>
            </div>
          </div>
          <button
            className="carousel-control-prev"
            type="button"
            data-bs-target="#carouselExampleFade"
            data-bs-slide="prev"
          >
            <span
              className="carousel-control-prev-icon"
              aria-hidden="true"
            ></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button
            className="carousel-control-next"
            type="button"
            data-bs-target="#carouselExampleFade"
            data-bs-slide="next"
          >
            <span
              className="carousel-control-next-icon"
              aria-hidden="true"
            ></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
        <Shop/>

        <div
          style={{ width: "100%", height: "auto", backgroundColor: "#8fe3a8" }}
        >
          <div className="about-3" style={{ marginTop: "30px" }}>
            <div className="content">
              <h2 className="font">
                We are a digital-first, life sciences commercialization company
              </h2>
              <p>
                We help biopharmaceutical, emerging biotech and medical device
                companies develop products, get them to the market, and grow
                their impact through the life cycle in a more effective,
                efficient, and modern way. We bring together healthcare domain
                expertise, fit-for-purpose technology, and an agile operating
                model to provide a diverse range of solutions. These aim to
                deliver, amongst other outcomes, a personalized, scalable and
                omnichannel experience for patients and physicians. It’s what
                drives our team and our purpose to enable healthcare
                organizations to be future ready.
              </p>
              <button className="read-more-btn">Read More</button>
            </div>
            <img
              src={Sade1}
              className="d-block imge1"
              width="200px"
              height="150px"
              alt="..."
            />
          </div>
        </div>
        <div className="boox">
          <div className="box10">
            <div className="left11">
              <h1>80%</h1>
              <p>clinical trials fail to recruit enough participants on time</p>
            </div>
          </div>
          <div className="box10">
            <div className="left11">
              <h1>93%</h1>
              <p>
                participants do not complete trials, compromising statistical
                relevance
              </p>
            </div>
          </div>
          <div className="box10">
            <div className="left11">
              <h1 className="left13">$40,000</h1>
              <p>
                is the average investment for every clinical trial participant
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className="slder1">
        <h1>Existing clinical operations are still</h1>
        <div className="boxser">
          <div className="boxes">
            <h3>Dependent</h3>
            <p>on paper-based means of capturing data</p>
          </div>
          <div className="boxes">
            <h3>Suboptimal</h3>
            <p>in mining data for targeted patient recruitment</p>
          </div>
          <div className="boxes">
            <h3>Underprepared</h3>
            <p>for decentralized clinical trials</p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

export default CustHome;
