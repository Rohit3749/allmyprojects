import React, {useState} from 'react'
import Footer from '../comp/Footer';
import CustNavber from './CustNavber';
import axios from 'axios';
import toast,{Toaster} from 'react-hot-toast'
import { useNavigate } from 'react-router-dom';
const initialState={
  oldpassword:"",
  newpassword:""
}

function ChangePassword() {
  const [state,setState]=useState(initialState);
  const [status,setStatus]=useState('');
  const navigate=useNavigate();
  const {oldpassword,newpassword}=state;
  const handleInput=(e)=>{
  const {name,value}=e.target
  setState({...state,[name]:value});
}
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:5000/change",state)
    .then((response)=>{
      //setState({oldpassword:"",newpassword:""});
      if(response.data.success){
        toast.success(response.data.message)
        setTimeout(()=>navigate('/login'),2000);
      }
      else if(response.data.success===false){
        toast.error(response.data.message)
      }
    })
    .catch((error)=>{
      console.log(error);
    })
  
};
  return (
    <>
    <div className='container container-fluid'></div>
    <CustNavber />
    <div>
        <div
          className="container my-5"
          style={{background: 'radial-gradient(circle, rgba(63,193,251,1) 0%, rgba(70,252,134,1) 100%)',borderRadius:'10px 30% 10px 30%',boxShadow: '5px 10px 18px #888888' }}
        >
          <div className="row">
            <form className="form-group" onSubmit={handleSubmit} >
              <div class="col-md-6 offset-md-3">
                <div className="login-form p-5">
                <h2 style={{fontFamily:"cursive",marginBottom:'40px',color:'#f3f6f6'}}>Change Password Form</h2>
                  <div className="form-floating mb-3">
                    <input
                      type="password"
                      className="form-control"
                      id="floatingInput"
                      name="oldpassword"
                      required
                      onChange={handleInput}
                    />
                    <label for="floatingInput">Old Password</label>
                  </div>
                  <div className="form-floating mb-3">
                    <input
                      type="password"
                      className="form-control"
                      id="floatingInput"
                      name="newpassword"
                      required
                      onChange={handleInput}
                    />
                    <label for="floatingInput">New Password</label>
                  </div>
                  <div className="form-floating">
                    <input
                      type="password"
                      className="form-control "
                      id="floatingPassword"
                      name="confirmpassword"
                      required
                      onChange={handleInput}
                    />
                    <label for="floatingPassword">Confirm Password</label>
                    <button type="submit" className="btn btn-info mt-3 ">
                      Change
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <h3>{status}</h3>
          </div>
        </div>
      </div>
<Toaster/>
    <Footer />
    </>
  )
}

export default ChangePassword;