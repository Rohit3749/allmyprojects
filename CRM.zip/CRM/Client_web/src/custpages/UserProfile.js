var UserProfile=(function(){
    var userid="";
    var getUserId=function(){
        return userid;
    };
    var setUserId=function(uid){
        userid=uid;
    };
    return{
        getUserId:getUserId,
        setUserId:setUserId
    }
})();
export default UserProfile;