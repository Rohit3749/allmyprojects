import React from 'react'
import logo from '../IMG/logo.jpg';
import { Toaster } from 'react-hot-toast';

function Header1() {
  return (
    <div className='row' style={{minHeight:'150px'}}>
        <div className='col-sm-3'>
        <img src={logo} width='150px' height='150' />
        </div>
        <div className='col-sm-9' style={{backgroundColor:'navy',color:'white', fontSize:'30px',textAlign:'center',lineHeight:'150px'}}>
            WelCome to Custmoer Zone
          
        </div>
        <Toaster/>
    </div>
  )
}

export default Header1;