import React from 'react'
import "./Shop.css";
import fd1 from "./../IMG/fd1.png";
import fd2 from "./../IMG/fd2.png";
import fd3 from "./../IMG/fd.3.png";
import fd4 from "./../IMG/fd4.png";
import fd5 from "./../IMG/fd5.png";
import al1 from "./../IMG/al1.png";
import al2 from "./../IMG/al2.png";
import al3 from "./../IMG/al3.png";
import al4 from "./../IMG/al4.png";
import al5 from "./../IMG/al5.png";
import ss1 from "./../IMG/ss1.png";
import ss2 from "./../IMG/ss2.png";
import ss3 from "./../IMG/ss3.png";
import ss4 from "./../IMG/ss4.png";
import ss5 from "./../IMG/ss5.png";
import Mid from "./../IMG/mid.png";
import Bar from "./../IMG/bar.png";


function Shop() {
  return (
    <>
        <div className="main">
        <h2>Food Supplements</h2>
            <div className="shop">
                <img src={fd1} width='150' />
                <h5><b>Isadiet Plus</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>223</b> Reviews</p>
                <h6>&#8377; <b>225</b> &#8377;<del>250</del> &#8377; <b style={{color:'green'}}>25% off</b></h6>
            </div>
            <div className="shop">
                <img src={fd3} width='150' />
                <h5><b>Isadiet Sugar F..</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>432</b> Reviews</p>
                <h6>&#8377; <b>166</b> &#8377;<del>175</del> &#8377; <b style={{color:'green'}}>9% off</b></h6>
            </div>
            <div className="shop">
                <img src={fd4} width='150' />
                <h5><b>Bonesafe Plus T..</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>31</b> Reviews</p>
                <h6>&#8377; <b>247</b> &#8377;<del>275</del> &#8377; <b style={{color:'green'}}>28% off</b></h6>
            </div>
            <div className="shop">
                <img src={fd2} width='150' />
                <h5><b>Isadiet Plus</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>23</b> Reviews</p>
                <h6>&#8377; <b>550</b> &#8377;<del>650</del> &#8377; <b style={{color:'green'}}>46% off</b></h6>
            </div>
            <div className="shop">
                <img src={fd5} width='150' />
                <h5><b>Bone safe S.</b></h5>
                <p><b>3.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>13</b> Reviews</p>
                <h6>&#8377; <b>299</b> &#8377;<del>319</del> &#8377; <b style={{color:'green'}}>20% off</b></h6>
            </div>
        </div>
        <div className="main">
        <h2>Ayurvedic Medicines</h2>
            <div className="shop">
                <img src={al1} width='150' />
                <h5><b>Marc Uro 5</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>42</b> Reviews</p>
                <h6>&#8377; <b>290</b> &#8377;<del>300</del> &#8377; <b style={{color:'green'}}>10% off</b></h6>
            </div>
            <div className="shop">
                <img src={al2} width='150' />
                <h5><b>Marcogesic Oil ..</b></h5>
                <p><b>3.9</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>64</b> Reviews</p>
                <h6>&#8377; <b>199</b> &#8377;<del>215</del> &#8377; <b style={{color:'green'}}>16% off</b></h6>
            </div>
            <div className="shop">
                <img src={al3} width='150' />
                <h5><b>Inhale Easy Spr..</b></h5>
                <p><b>3.8</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>65</b> Reviews</p>
                <h6>&#8377; <b>99</b> &#8377;<del>119</del> &#8377; <b style={{color:'green'}}>12% off</b></h6>
            </div>
            <div className="shop">
                <img src={al4} width='150' />
                <h5><b>G DON plus</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>87</b> Reviews</p>
                <h6>&#8377; <b>399</b> &#8377;<del>435</del> &#8377; <b style={{color:'green'}}>36% off</b></h6>
            </div>
            <div className="shop">
                <img src={al5} width='150' />
                <h5><b>Marc Uro 5 Pack..</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>12</b> Reviews</p>
                <h6>&#8377; <b>999</b> &#8377;<del>1200</del> &#8377; <b style={{color:'green'}}>201% off</b></h6>
            </div>
        </div>
        <div className="main">
        <h2>Stomach Syrup</h2>
            <div className="shop">
                <img src={ss1} width='150' />
                <h5><b>Lactulac Syrup</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>987</b> Reviews</p>
                <h6>&#8377; <b>243</b> &#8377;<del>256</del> &#8377; <b style={{color:'green'}}>13% off</b></h6>
            </div>
            <div className="shop">
                <img src={ss2} width='150' />
                <h5><b>MarcoZyme Sy</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>1k</b> Reviews</p>
                <h6>&#8377; <b>550</b> &#8377;<del>650</del> &#8377; <b style={{color:'green'}}>6% off</b></h6>
            </div>
            <div className="shop">
                <img src={ss3} width='150' />
                <h5><b>Aciblock MPS</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>74</b> Reviews</p>
                <h6>&#8377; <b>101</b> &#8377;<del>107</del> &#8377; <b style={{color:'green'}}>46% off</b></h6>
            </div>
            <div className="shop">
                <img src={ss4} width='150' />
                <h5><b>SILYLIV</b></h5>
                <p><b>2.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>7</b> Reviews</p>
                <h6>&#8377; <b>66</b> &#8377;<del>73</del> &#8377; <b style={{color:'green'}}>7% off</b></h6>
            </div>
            <div className="shop">
                <img src={ss5} width='150' />
                <h5><b>Aciblock O</b></h5>
                <p><b>3.3</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>41</b> Reviews</p>
                <h6>&#8377; <b>123</b> &#8377;<del>130</del> &#8377; <b style={{color:'green'}}>46% off</b></h6>
            </div>
        </div>
        <div className="mid-img">
            <img src={Mid} width='1250'  />
        </div>
        <div className="main">
        <h2>Selling Product Most</h2>
            <div className="shop">
                <img src={ss1} width='150' />
                <h5><b>Lactulac Syrup</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>987</b> Reviews</p>
                <h6>&#8377; <b>243</b> &#8377;<del>256</del> &#8377; <b style={{color:'green'}}>13% off</b></h6>
            </div>
            <div className="shop">
                <img src={ss2} width='150' />
                <h5><b>MarcoZyme Sy</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>1k</b> Reviews</p>
                <h6>&#8377; <b>550</b> &#8377;<del>650</del> &#8377; <b style={{color:'green'}}>6% off</b></h6>
            </div>
            <div className="shop">
                <img src={al2} width='150' />
                <h5><b>Aciblock MPS</b></h5>
                <p><b>4.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>74</b> Reviews</p>
                <h6>&#8377; <b>101</b> &#8377;<del>107</del> &#8377; <b style={{color:'green'}}>46% off</b></h6>
            </div>
            <div className="shop">
                <img src={ss4} width='150' />
                <h5><b>SILYLIV</b></h5>
                <p><b>2.0</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>7</b> Reviews</p>
                <h6>&#8377; <b>66</b> &#8377;<del>73</del> &#8377; <b style={{color:'green'}}>7% off</b></h6>
            </div>
            <div className="shop">
                <img src={fd2} width='150' />
                <h5><b>Aciblock O</b></h5>
                <p><b>3.3</b> <span style={{fontSize:'15px',color:'yellow'}}>&#9734;</span>Rating & <b>41</b> Reviews</p>
                <h6>&#8377; <b>123</b> &#8377;<del>130</del> &#8377; <b style={{color:'green'}}>46% off</b></h6>
            </div>
        </div>
        <div className="mid-img">
            <img src={Bar} width='1250'  />
        </div>
    </>
  )
}

export default Shop