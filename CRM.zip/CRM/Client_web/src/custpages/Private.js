import React from 'react'

const Private=()=> {
  return (
    <div>Private</div>
  )
}

export default Private