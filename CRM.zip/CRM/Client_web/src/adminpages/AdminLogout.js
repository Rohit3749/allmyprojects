import React from 'react'
import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

export default function AdminLogout() {
    const navigate=useNavigate();
    useEffect(()=>{
        setTimeout(()=>navigate("/login"),500);
    })
  return (
    <div>

    </div>
  )
}
