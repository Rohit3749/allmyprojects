import React,{useEffect, useState} from 'react'
import AdminHeader from './AdminHeader'
import axios from 'axios'

export default function Enquiries() {
  const [data,setData]=useState([]);
  const loadData=async()=>{
    const response=await axios.get("http://localhost:5000/viewenquiries");
    setData(response.data);
  }
  useEffect(()=>{
    loadData();
  },[]);
  const deleteEnquiries =(id)=>{
    const resp = window.confirm("Are You Sure")
    if(resp){
      axios.delete(`http://localhost:5000/deleteenquiries/${id}`).then((res)=>{
      loadData()
    })
    }
  }
  return (
    <>
    <AdminHeader/>
    <div className="mainDiv2">
    <div className="cardStyle2">
    <form action="" method="post" name="signupForm" id="signupForm">
    <div className="" >
            <div className="col-sm-12 text-light">
              <h2 className="formTitle" style={{alignItems:'center',marginTop:'50px'}}>View All Enquiries</h2>
              <table className='table'>
                <thead className='text-light'>
                  <tr style={{color:'black'}}>
                    <th>Name</th>
                    <th>Contact No</th>
                    <th>Email Address</th>
                    <th>Subject</th>
                    <th>Message</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    data.map((value,index)=>{
                      return(
                        <tr key={value.id}>
                          <td>{value.name}</td>
                          <td>{value.contactno}</td>
                          <td>{value.emailaddress}</td>
                          <td>{value.subject}</td>
                          <td>{value.message}</td>
                          <td><button className='btn btn-danger' onClick={()=>deleteEnquiries(value.id)}>Delete</button></td>
                        </tr>
                      );
                    })
                  }
                </tbody>
              </table>
            </div>
</div>
</form>
</div>
   </div>
    </>
    )
}
