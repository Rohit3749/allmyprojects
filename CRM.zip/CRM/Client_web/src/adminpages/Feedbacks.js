import AdminHeader from "./AdminHeader";
import React,{useEffect, useState} from 'react'
import axios from 'axios'


export default function Feedbacks() {
  const [data,setData]=useState([]);
  const loadData=async()=>{
    const response=await axios.get("http://localhost:5000/viewfeedback");
    setData(response.data);
  }
  useEffect(()=>{
    loadData();
  },[]);
  const deleteFeedback =(id)=>{
    const resp = window.confirm("Are You Sure")
    if(resp){
      axios.delete(`http://localhost:5000/deletefeedback/${id}`).then((res)=>{
      loadData()
    })
    }
  }
  return (
    <>
      <AdminHeader />
      <div style={{marginLeft:'40px'}} >
            <div className="col-sm-12 text-light">
              <h2 className="formTitle" style={{alignItems:'center',marginTop:'50px'}}>View All Feedback</h2>
              <table className='table' style={{width:'90%',margin:'0 auto'}}>
                <thead className='text-light'>
                  <tr style={{color:'black'}}>
                    <th>Name</th>
                    <th>Contact No</th>
                    <th>Subject</th>
                    <th>Feedback</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    data.map((value,index)=>{
                      return(
                        <tr key={value.id}>
                          <td>{value.name}</td>
                          <td>{value.contactno}</td>
                          <td>{value.subject}</td>
                          <td>{value.feedbacktext}</td>
                          <td><button className='btn btn-danger' onClick={()=>deleteFeedback(value.id)}>Delete</button></td>
                        </tr>
                      );
                    })
                  }
                </tbody>
              </table>
            </div>
</div>

    </>
  );
}
