import React, {useState} from 'react'
import './Sadbar.css'
import { Link } from "react-router-dom";

const AdminHeader=()=> {

  const [show, setShow] = useState(false)
  return  <main className={show ? 'space-toggle' :null}>
      <header className={`header ${show ? 'space-toggle' : null}`}>
        <div className="header-toggle" onClick={() => setShow(!show)} style={{display:'flex'}}>
        <i className="fa-solid fa-bars"></i>
        <h2 style={{margin:"0",marginLeft:'10px',color:'white'}}>Dashboard</h2>
        </div>
      </header>
      <aside className={`sidebar ${show ? 'show' : null}`}>
        <nav className="nav">
          <div>
            <Link to="/adminzone/adminhome" className="nav-logo">
              <i className="fas fa-home-alt nav-logo-icon"></i>
              <span className="nav-logo-name">Adminzone</span>
            </Link>
            <div className="nav-list">
            <Link to="/adminzone/adminhome" className="nav-link active">
            <i className="fa-solid fa-gauge-high nav-link-icon"></i>
             <span className="nav-link-name">Adminzone</span>
            </Link>
            <Link to="/adminzone/customers" className="nav-link">
            <i className="fas fa-user nav-link-icon"></i>
             <span className="nav-link-name">Customers</span>
            </Link>
            <Link to="/adminzone/feedbacks" className="nav-link">
            <i className="fas fa-comments nav-link-icon"></i>
             <span className="nav-link-name">Feedbacks</span>
            </Link>
            <Link to="/adminzone/complains" className="nav-link">
            <i className="fas fa-comments nav-link-icon"></i>
             <span className="nav-link-name">Camplains</span>
            </Link>
            <Link to="/adminzone/enquiries" className="nav-link">
            <i className="fas fa-question-circle nav-link-icon"></i>
             <span className="nav-link-name">Enquiries</span>
            </Link>
            <Link to="/adminzone/adminchangepassword" className="nav-link">
            <i className="fas fa-key nav-link-icon"></i>
             <span className="nav-link-name">Change Password</span>
            </Link>
            </div>
          </div>
          <Link to="/adminzone/adminlogout" className="nav-link">
            <i className="fas fa-power-off nav-link-icon"></i>
             <span className="nav-link-name">Logout</span>
            </Link>
        </nav>
      </aside>
    </main>
  
}

export default AdminHeader;