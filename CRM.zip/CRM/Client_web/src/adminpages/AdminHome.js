import React, { useEffect } from "react";
import { useState } from "react";
import axios from "axios";
import AdminHeader from "./AdminHeader";
import './AdminHeader.css'
export default function AdminHome() {
  const [notification,setNotification]=useState("");
  const [data,setData]=useState([]);

  const handleInput=(e)=>{
      setNotification(e.target.value);
  };
  const handleSubmit=(e)=>{
      e.preventDefault();
      axios.post("http://localhost:5000/add",{
          notificationtext: notification,
      })
      .then((res) => {
          setNotification("");
          loadData()
      })
      .catch((err)=>{
          console.log(err);
      })
  }
  const loadData=async()=>{
      const response=await axios.get("http://localhost:5000/viewnotification");
      setData(response.data);
  }
  useEffect(()=>{
      loadData();
  },[]);
  const deleteNotification=(id)=>{
      if(window.confirm("Are you sure"))
      {
          axios.delete(`http://localhost:5000/deletenotification/${id}`).then((res)=>[
            setTimeout(()=>loadData(),500)
          ])
      }
      
  }
  return (
    <>
    <AdminHeader/>
   <div className="mainDiv">
          <div className="cardStyle">
            <form action="" name="signupForm" id="signupForm" onSubmit={handleSubmit}>
              <img src="" id="signupLogo" />

              <h2 className="formTitle">Add News & Events</h2>
              <div className="inputDiv">
                <label className="inputLabel" >
                 Enter Notification
                </label>
                <textarea
                  type="text"
                  id="confirmPassword"
                  name="notificationtext"
                  onChange={handleInput}
                  value={notification}
                />
              </div>

              <div className="buttonWrapper">
                <button
                  type="submit"
                  id="submitButton"
                //   onclick="validateSignupForm()"
                  className="submitButton pure-button pure-button-primary"
                >
                  <span>Add</span>
                </button>
              </div>
            </form>
            <br/> <br/>
            <table className="table" style={{margin:'0 auto',width:'70%'}}>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Notification</th>
                        <th>posted Date</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        data.map((value,index)=>{
                            return(
                                <tr key={value.id}>
                                    <td>{index+1}</td>
                                    <td>{value.notificationtext}</td>
                                    <td>{value.posteddate}</td>
                                    <td>
                                        <button onClick={()=>deleteNotification(value.id)}>Delete</button>
                                    </td>
                                </tr>
                            );
                        })
                    }
                </tbody>
            </table>
          </div>
          </div>
    
    </>
  )
}
