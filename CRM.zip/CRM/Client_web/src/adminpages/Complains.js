import React,{useEffect, useState} from 'react'
import AdminHeader from './AdminHeader'
import axios from 'axios'

export default function Complains() {
  const [data,setData]=useState([]);
  const loadData=async()=>{
    const response=await axios.get("http://localhost:5000/viewcomplain");
    setData(response.data);
  }
  useEffect(()=>{
    loadData();
  },[]);
  const deleteComplain =(id)=>{
    const resp = window.confirm("Are You Sure")
    if(resp){
      axios.delete(`http://localhost:5000/deletecomplain/${id}`).then((res)=>{
      loadData()
    })
    }
  }
  return (
    <>
      <AdminHeader/>
      <div style={{marginLeft:'40px'}} >
            <div className="col-sm-12 text-light">
              <h2 className="formTitle" style={{alignItems:'center',marginTop:'50px'}}>View All Complains</h2>
              <table className='table' style={{width:'90%',margin:'0 auto'}}>
                <thead className='text-light'>
                  <tr style={{color:'black'}}>
                    <th>Name</th>
                    <th>Contact No</th>
                    <th>Subject</th>
                    <th>Complaintext</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {
                    data.map((value,index)=>{
                      return(
                        <tr key={value.id}>
                          <td>{value.name}</td>
                          <td>{value.contactno}</td>
                          <td>{value.subject}</td>
                          <td>{value.complaintext}</td>
                          <td><button className='btn btn-danger' onClick={()=>deleteComplain(value.id)}>Delete</button></td>
                        </tr>
                      );
                    })
                  }
                </tbody>
              </table>
            </div>
</div>

    </>
  )
}
