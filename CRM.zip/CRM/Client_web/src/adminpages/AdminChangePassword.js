import React, {useState} from "react";
import AdminHeader from "./AdminHeader";
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import toast,{Toaster} from 'react-hot-toast'
import './AdminHeader.css'
const initialState={
  oldpassword:"",
  newpassword:"",
  confirmPassword:""
}

export default function AdminChangePassword() {
  const [state,setState]=useState(initialState);
  const [status,setStatus]=useState('');
  const navigate=useNavigate();
  const {oldpassword,newpassword,confirmPassword}=state;
  const handleInput=(e)=>{
  const {name,value}=e.target
  setState({...state,[name]:value});
}
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:5000/adminpasswordchane",state)
    .then((response)=>{
      setState({oldpassword:"",newpassword:"",confirmPassword:""});
     navigate("/adminzone/adminlogout")
    })
    .catch((error)=>{
      console.log(error);
    })
  
};
  return (
    <>
    <AdminHeader/>
        <div className="mainDiv">
          <div className="cardStyle">
            <form id="signupForm" onSubmit={handleSubmit}>
              <img src="" id="signupLogo" />

              <h2 className="formTitle">Change Password 👍  </h2>

              <div className="inputDiv">
                <label className="inputLabel" for="password">
                  Old Password
                </label>
                <input type="password" id="password" name="oldpassword" onChange={handleInput} required />
              </div>
              <div className="inputDiv">
                <label className="inputLabel" for="password">
                  New Password
                </label>
                <input type="password" id="password" name="newpassword" onChange={handleInput} required />
              </div>

              <div className="inputDiv">
                <label className="inputLabel" for="confirmPassword">
                  Confirm Password
                </label>
                <input
                  type="password"
                  id="confirmPassword"
                  name="confirmPassword"
                  onChange={handleInput}
                />
              </div>

              <div className="buttonWrapper">
                <button
                  type="submit"
                  id="submitButton"
                  className="submitButton pure-button pure-button-primary"
                >
                  <span>Continue</span>
                </button>
              </div>
            </form>
            <h3>{status}</h3>
          </div>
        </div>
        </> 
  );
}
