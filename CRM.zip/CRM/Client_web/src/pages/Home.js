import Layout from "../comp/Layout";
import Sad1 from "./../IMG/image1.jpg";
import Sad2 from "./../IMG/image2.jpg";
import Sad3 from "./../IMG/image3.jpg";
import Sad4 from "./../IMG/image4.jpg";
import Sade from "./../IMG/sade.png";
import Doct from "./../IMG/doc.png";
import Slution from "./../IMG/sol.png";
import Date from "./../IMG/date.png";
import Ala from "./../IMG/ala1.png";
import Logy from "./../IMG/logy.png";
import Eye from "./../IMG/eye.png";
import Daily from "./../IMG/daily.png";
import Ortho from "./../IMG/artho.png";
import React from "react";
import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";
import "./About.css";
import "./Contact.css";
import Background from "../IMG/bg3.png";
import Notifi from "../comp/Notifi";

const initialState = {
  name: "",
  contactno: "",
  emailaddress: "",
  subject: "",
  message: "",
};

const Home = () => {
  const [state, setState] = useState(initialState);
  const { name, contactno, emailaddress, subject, message } = state;
  const navigate = useNavigate();

  const handleInput = (e) => {
    const { name, value } = e.target;
    setState({ ...state, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:5000/contact", state)
      .then(() => {
        setState({
          name: "",
          contactno: "",
          emailaddress: "",
          subject: "",
          message: "",
        });
      })
      .catch((err) => {
        console.log(err);
      });
    setTimeout(() => navigate("/"), 500);
  };
  return (
    <Layout>
      {/* Start Home Pages */}
      <div
        id="carouselExampleFade"
        className="carousel slide carousel-fade"
        data-bs-ride="carousel"
      >
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img
              src={Sad1}
              className="d-block w-100"
              width="80%"
              height="300px"
              alt="..."
            />
          </div>
          <div className="carousel-item">
            <img
              src={Sad2}
              className="d-block w-100"
              height="300px"
              alt="..."
            />
          </div>
          <div className="carousel-item">
            <img
              src={Sad3}
              className="d-block w-100"
              height="300px"
              alt="..."
            />
          </div>
          <div className="carousel-item">
            <img
              src={Sad4}
              className="d-block w-100"
              height="300px"
              alt="..."
            />
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleFade"
          data-bs-slide="prev"
        >
          <span
            className="carousel-control-prev-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleFade"
          data-bs-slide="next"
        >
          <span
            className="carousel-control-next-icon"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>
      <Notifi/>
        <div className="easy-to">
        <h1>Esay steps for your solution</h1>
        <div className="doc-tor">
          <img src={Doct} className="imge" alt="..." />
          <h2>Search Doctor</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
        </div>
        <div className="doc-tor">
          <img src={Ala} className="imge2" alt="..." />
          <h2 className="text-text">Request & Consultation</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
        </div>
        <div className="doc-tor">
          <img src={Date} className="imge2" alt="..." />
          <h2 className="text-text">Make Appoinment</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
        </div>
        <div className="doc-tor">
          <img src={Slution} className="imge2" alt="..." />
          <h2 className="text-text">Get Solution</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
        </div>
      </div>
      <div className="about-3">
        <div className="content">
          <h2 className="font">We give the perfect smile you wanted</h2>
          <p>
            Although it’s important to include your accomplishments and your
            experience, do so in a reasonable manner, avoiding outlandish
            statements. Declarations like, “I’m the best marketing professional
            there is” or “Any company that brings me on board is lucky to have
            me” will certainly hurt you more than it will help you get hired.
          </p>
          <button className="read-more-btn">Read More</button>
        </div>
        <img
          src={Sade}
          className="d-block imge1"
          width="200px"
          height="150px"
          alt="..."
        />
      </div>
      <div className="easy-to1">
        <h1 className="font">Esay steps for your solution</h1>
        <div className="doc-tor1">
          <img src={Logy} className="imge" alt="..." />
          <h2>Cardiology</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
          <p className="button1">Read More</p>
        </div>
        <div className="doc-tor1">
          <img src={Daily} className="imge2" alt="..." />
          <h2 className="text-text">Dialysis</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
          <p className="button1">Read More</p>
        </div>
        <div className="doc-tor1">
          <img src={Eye} className="imge2" alt="..." />
          <h2 className="text-text">Eye Care</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
          <p className="button1">Read More</p>
        </div>
        <div className="doc-tor1">
          <img src={Ortho} className="imge2" alt="..." />
          <h2 className="text-text">Orthopedic</h2>
          <p className="text1">Your Any Doctor Search Any Queries </p>
          <p className="button1">Read More</p>
        </div>
      </div>
      {/* Start about us pages */}
      <section id="about">
        <div className="about-1">
          <h1>ABOUT US</h1>
          <p>
            An "About Me" page is one of the most important parts of your
            portfolio, website, or blog. This page is where prospective
            employers, potential clients, website users, and other professional
            and personal connections go to learn about who you are and what you
            do.1 It's an ideal resource for promoting your professional brand.
          </p>
        </div>
        <div id="about-2">
          <div className="content-box-lg">
            <div className="container">
              <div className="row">
                <div className="col-md-4">
                  <div className="about-item text-center">
                    <h3>MISSION</h3>
                    <hr></hr>
                    <p>
                      Madison is fueled by her passion for understanding the
                      nuances of cross-cultural advertising. She considers
                      herself a "forever student," eager to both build on her
                      academic foundations in psychology and sociology, and
                      stays in tune with the latest digital marketing strategies
                      through continued coursework and professional development.
                    </p>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="about-item text-center">
                    <h3>VISSION</h3>
                    <hr></hr>
                    <p>
                      A personal website can help job seekers promote their
                      credentials and portfolio, share information about their
                      skills and attributes, and market their candidacy. It can
                      be an excellent resource to use to provide additional
                      information to prospective employers, but it’s not a
                      requirement. Unless you have the time and resources to
                      create a compelling page, it’s better not.
                    </p>
                  </div>
                </div>
                <div className="col-md-4">
                  <div className="about-item text-center">
                    <h3>ACHIEVEMENTS</h3>
                    <hr></hr>
                    <p>
                      Madison is fueled by her passion for understanding the
                      nuances of cross-cultural advertising. She considers
                      herself a "forever student," eager to both build on her
                      academic foundations in psychology and sociology, and
                      stays in tune with the latest digital marketing strategies
                      through continued coursework and professional development.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="about-3">
          <img
            src={Background}
            className="d-block w-100"
            width="200px"
            height="150px"
            alt="..."
          />
          <div className="content">
           <marquee direction="up"> <p>
              Although it’s important to include your accomplishments and your
              experience, do so in a reasonable manner, avoiding outlandish
              statements. Declarations like, “I’m the best marketing
              professional there is” or “Any company that brings me on board is
              lucky to have me” will certainly hurt you more than it will help
              you get hired.
            </p></marquee>
            <button className="read-more-btn">Read More</button>
          </div>
        </div>
      </section>
      {/* Start Contact Us Pages */}
      <div className="container-contact">
        <h1>Contact With Us</h1>
        <p>
          We would love to your queries and help you succeed. Feel free to get
          in touch with us.
        </p>
        <div className="contact-box">
          <div className="contact-left">
            <h3>Send your request</h3>
            <form onSubmit={handleSubmit}>
              <div className="input-row">
                <div className="input-group">
                  <label>Name</label>
                  <input
                    type="text"
                    placeholder="Username"
                    name="name"
                    onChange={handleInput}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>Phone</label>
                  <input
                    type="number"
                    placeholder="1234567890"
                    name="contactno"
                    onChange={handleInput}
                    required
                  />
                </div>
              </div>
              <div className="input-row">
                <div className="input-group">
                  <label>Email</label>
                  <input
                    type="email"
                    placeholder="Username@gmail.com"
                    name="emailaddress"
                    onChange={handleInput}
                    required
                  />
                </div>
                <div className="input-group">
                  <label>Subject</label>
                  <input
                    type="text"
                    placeholder="Type here"
                    name="subject"
                    onChange={handleInput}
                    required
                  />
                </div>
              </div>
              <label>Message</label>
              <textarea
                rows="5"
                placeholder="type here your message"
                name="message"
                onChange={handleInput}
              ></textarea>
              <button type="submit">SEND</button>
            </form>
          </div>
          <div className="contact-right">
            <h3>Reach Us</h3>
            <table>
              <tr>
                <td>Email</td>
                <td>contactus@gmail.com</td>
              </tr>
              <tr>
                <td>Phone</td>
                <td>+91-11-2222-4444</td>
              </tr>
              <tr>
                <td>Address</td>
                <td>
                  101, E1 First floor, pandey Market <br></br>
                  Jamapur, Jiradei, Siwan <br></br>
                  Bihar (841245){" "}
                </td>
              </tr>
            </table>
          </div>
        </div>
      </div>

      
    </Layout>
  );
};
export default Home;
