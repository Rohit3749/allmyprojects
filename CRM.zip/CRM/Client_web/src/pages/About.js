import React from 'react'
import "./About.css";
import Layout from '../comp/Layout';
import Notifi from '../comp/Notifi';
import Background from '../IMG/bg3.png';

function About() {
  return (
    <Layout>
    <Notifi/>
    <section id='about'>
      <div className='about-1'>
        <h1>ABOUT US</h1>
        <p>An "About Me" page is one of the most important parts of your portfolio, website, or blog. This page is where prospective employers, potential clients, website users, and other professional and personal connections go to learn about who you are and what you do.1 It's an ideal resource for promoting your professional brand.</p>
      </div>
      <div id='about-2'>
        <div className='content-box-lg'>
        <div className='container'>
        <div className='row'>
        <div className='col-md-4'>
        <div className='about-item text-center'>
          <h3>MISSION</h3>
          <hr></hr>
          <p>Madison is fueled by her passion for understanding the nuances of cross-cultural advertising. She considers herself a "forever student," eager to both build on her academic foundations in psychology and sociology, and stays in tune with the latest digital marketing strategies through continued coursework and professional development.</p>
        </div>
        </div>
        <div className='col-md-4'>
        <div className='about-item text-center'>
          <h3>VISSION</h3>
          <hr></hr>
          <p>A personal website can help job seekers promote their credentials and portfolio, share information about their skills and attributes, and market their candidacy. It can be an excellent resource to use to provide additional information to prospective employers, but it’s not a requirement. Unless you have the time and resources to create a compelling page, it’s better not.</p>
        </div>
        </div>
        <div className='col-md-4'>
        <div className='about-item text-center'>
          <h3>ACHIEVEMENTS</h3>
          <hr></hr>
          <p>Madison is fueled by her passion for understanding the nuances of cross-cultural advertising. She considers herself a "forever student," eager to both build on her academic foundations in psychology and sociology, and stays in tune with the latest digital marketing strategies through continued coursework and professional development.</p>
        </div>
        </div>
        </div>
        </div>
        </div>
      </div>
      <div className='about-3'>
      <img
              src={Background}
              className="d-block w-100"
              width="200px"
              height="150px"
              alt="..."
            />
            <div className='content'>
          <p>Although it’s important to include your accomplishments and your experience, do so in a reasonable manner, avoiding outlandish statements. Declarations like, “I’m the best marketing professional there is” or “Any company that brings me on board is lucky to have me” will certainly hurt you more than it will help you get hired.</p>
          <button className='read-more-btn'>Read More</button>
            </div>
            </div>
    </section>
    </Layout>
  )
}

export default About;