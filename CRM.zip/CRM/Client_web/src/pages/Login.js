import React from "react";
import { useState, useEffect } from "react";
import axios from "axios";
import Background from "../IMG/bg.png";
import { useNavigate } from "react-router-dom";
import toast from 'react-hot-toast';
import Layout from "../comp/Layout";
const initialState = {
  userid: "",
  password: "",
};
function Login() {
  const [state, setState] = useState(initialState);
  const [loginStatus, setLoginStatus] = useState("");
  const { userid, password } = state;
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;
  const handleInput = (e) => {
    const { name, value } = e.target;
    setState({ ...state, [name]: value });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:5000/login", state)
      .then((response) => {
        setState({ userid: "", password: "" });
        if (response.data.message) {
          toast.error("Password Not Matching");
          setLoginStatus(response.data.message);
        } else if(response.data.usertype=='customer') {
          setTimeout(()=>{
          navigate("/custzone/custhome");
          },2000);
          toast.success("Successfully");
        }else if(response.data.usertype=="admin"){
          navigate("/adminzone/adminhome");
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    axios.get("http://localhost:5000/login").then((response) => {
      if (response.data.loggedin == true) {
        //setLoginStatus(response.data.user[0].userid);
        //alert("successfully");
      }
    });
  }, []);
  return (
    <Layout>
      <div>
        <div
          className="container my-5"
          style={{ background: `url(${Background})` }}
        >
          <div className="row">
            <form className="form-group" onSubmit={handleSubmit}>
              <div class="col-md-6 offset-md-3">
                <div className="login-form p-5">
                  <div className="form-floating mb-3">
                    <input
                      type="text"
                      className="form-control"
                      id="floatingInput"
                      placeholder="userid"
                      name="userid"
                      onChange={handleInput}
                    />
                    <label for="floatingInput">Enter User Id</label>
                  </div>
                  <div className="form-floating">
                    <input
                      type="password"
                      className="form-control"
                      id="floatingPassword"
                      placeholder="Password"
                      name="password"
                      onChange={handleInput}
                    />
                    <label for="floatingPassword">Password</label>
                    <button type="submit" className="btn btn-info mt-3 shado "style={{width:'100px', height:'40px',backgroundColor:'#43e6b2',textAlign:'center',color:'white' ,boxShadow: '5px 5px 5px 0px rgba(0,0,0,0.3)'}}>
                      Login
                    </button>
                  </div>
                </div>
              </div>
            </form>
            <h2>{loginStatus}</h2>
          </div>
        </div>
      </div>
    </Layout>
  );
}

export default Login;
