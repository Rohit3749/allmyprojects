import React from 'react'
import axios from 'axios';
import { useEffect, useState } from 'react';
import {useNavigate} from 'react-router-dom';
import "./Contact.css";
import Layout from '../comp/Layout';
import Notifi from '../comp/Notifi';

const initialState={
  name:"",
  contactno:"",
  emailaddress:"",
  subject:"",
  message:""
}
function Contact() {
  const [state, setState]= useState(initialState);
  const{name,contactno,emailaddress,subject,message}=state;
  const navigate=useNavigate();

  const handleInput=(e)=>{
    const {name,value}=e.target;
    setState({...state,[name]:value});
  };
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:5000/contact",state)
    .then(()=>{
      setState({name:"",contactno:"",emailaddress:"",subject:"",message:""})
    }).catch((err)=>{
      console.log(err);
    })
    setTimeout(()=>navigate("/"),500);
  };
  return (
   <Layout>
   <Notifi/>
    <div className='container-contact'>
      <h1>Contact With Us</h1>
      <p>We would love to your queries and help you succeed. Feel free to get in touch with us.</p>
      <div className='contact-box'>
        <div className='contact-left'>
          <h3>Send your request</h3>
          <form onSubmit={handleSubmit}>
            <div className='input-row'>
              <div className='input-group'>
                <label>Name</label>
                <input type='text' placeholder='Username' name='name' onChange={handleInput} required/>
              </div>
              <div className='input-group'>
                <label>Phone</label>
                <input type='number' placeholder='1234567890' name='contactno'  onChange={handleInput} required />
              </div>
            </div>
            <div className='input-row'>
              <div className='input-group'>
                <label>Email</label>
                <input type='email' placeholder='Username@gmail.com' name='emailaddress'  onChange={handleInput} required />
              </div>
              <div className='input-group'>
                <label>Subject</label>
                <input type='text' placeholder='Type here' name='subject'  onChange={handleInput} required />
              </div>
            </div>
            <label>Message</label>
            <textarea rows='5' placeholder='type here your message' name='message'  onChange={handleInput}></textarea>
            <button type='submit'>SEND</button>
          </form>
        </div>
        <div className='contact-right'>
        <h3>Reach Us</h3>
        <table>
          <tr>
            <td>Email</td>
            <td>contactus@gmail.com</td>
          </tr>
          <tr>
            <td>Phone</td>
            <td>+91-11-2222-4444</td>
          </tr>
          <tr>
            <td>Address</td>
            <td>101, E1 First floor, pandey Market <br></br>
            Jamapur, Jiradei, Siwan <br></br>
            Bihar (841245) </td>
          </tr>
        </table>
        </div>
      </div>
    </div>
   </Layout>
  )
}

export default Contact;