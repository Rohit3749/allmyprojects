import React from 'react'
import Background from '../IMG/bg2.png';
import axios from 'axios';
import { useEffect, useState } from 'react';
import {useNavigate} from 'react-router-dom';
import Layout from '../comp/Layout';
const initialState={
  name:"",
  gender:"",
  address:"",
  contactno:"",
  emailaddress:"",
  password:""
}

function Registion() {
  const [state, setState]= useState(initialState);
  const{name,gender,address,contactno,emailaddress,password}=state;
  const navigate=useNavigate();

  const handleInput=(e)=>{
    const {name,value}=e.target;
    setState({...state,[name]:value});
  };
  const handleSubmit=(e)=>{
    e.preventDefault();
    axios.post("http://localhost:5000/regcode",{
      name,gender,contactno,address,emailaddress,password
    }).then(()=>{
      setState({name:"",gender:"",address:"",contactno:"",emailaddress:"",password:""})
    }).catch((err)=>{
      console.log(err);
    })
    setTimeout(()=>navigate("/"),500);
  }
  return (
    <Layout>
    <div>
         <div className="container my-5" style={{  background: `url(${Background})`,backgroundSize:'cover'}} >
        <div className="row">
        <form onSubmit={handleSubmit}>
          <div class="col-md-6 offset-md-3">
            <div className="login-form p-5">
              <div className="form-floating mb-3">
                <input
                  type="text"
                  className="form-control"
                  id="floatingInput"
                  placeholder="username"
                  onChange={handleInput}
                  name="name"
                />
                <label for="floatingInput">User Name</label>
              </div>
              <div className="form-floating mb-3">
                <input
                  type="email"
                  className="form-control"
                  id="floatingInput"
                  placeholder="example@gmail.com"
                  onChange={handleInput}
                  name="emailaddress"
                />
                <label for="floatingInput">Email address</label>
              </div>
              <div className="form-floating mb-3">
                <input
                  type="number"
                  className="form-control"
                  id="floatingInput"
                  placeholder="0000000000"
                  onChange={handleInput} name="contactno"
                />
                <label for="floatingInput">Contact</label>
              </div>
              <div className="form-floating mb-3">
                <input
                  type="text"
                  className="form-control"
                  id="floatingInput"
                  placeholder="Type here Your Address"
                  onChange={handleInput}
                  name="address"
                />
                <label for="floatingInput">Address</label>
              </div>
              <div className="form-floating mb-3">
              <td>
                <label htmlFor='gender' className='form-leble'>Select Gender</label>
              </td>
              <td>
                <input type="radio" name='gender' value='male' className='form-check-input mx-2'  onChange={handleInput} />Male
                <input type="radio" name='gender' value='female' className='form-check-input mx-2'  onChange={handleInput} />Female
              </td>
              </div>
              <div className="form-floating">
                <input
                  type="password"
                  className="form-control"
                  id="floatingPassword"
                  placeholder="Password"
                  onChange={handleInput}
                  name="password"
                />
                <label for="floatingPassword">Password</label>
                <button type="sumbit" className="btn btn-info mt-3 shado" style={{width:'100px', height:'40px',backgroundColor:'#43e6b2',textAlign:'center',boxShadow: '5px 5px 5px 0px rgba(0,0,0,0.3)',color:'white'}}>
                  Register
                </button>
              </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
    </Layout>
  )
}

export default Registion;