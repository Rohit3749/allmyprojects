import Header from "./comp/Header";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Footer from "./comp/Footer";
import Home from "./pages/Home";
import About from "./pages/About";
import Registion from "./pages/Registion";
import Login from "./pages/Login";
import Contact from "./pages/Contact";
import Header1 from "./custpages/Header1";
import CustHome from "./custpages/CustHome";
import Feedback from "./custpages/Feedback";
import Complain from "./custpages/Complain";
import ChangePassword from "./custpages/ChangePassword";
import Logout from "./custpages/Logout";
import AdminHome from "./adminpages/AdminHome";
import Customers from "./adminpages/Customers";
import Feedbacks from "./adminpages/Feedbacks";
import Complains from "./adminpages/Complains";
import Enquiries from "./adminpages/Enquiries";
import AdminChangePassword from "./adminpages/AdminChangePassword";
import AdminLogout from "./adminpages/AdminLogout";
function App() {
  return (
    <>
      {/* <Header /> */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="contact" element={<Contact />} />
        <Route path="registration" element={<Registion />} />
        <Route path="login" element={<Login />} />
        <Route path="/custzone/custhome" element={<CustHome/>} />
        <Route path="/custzone/feedback" element={<Feedback/>} />
        <Route path="/custzone/complain" element={<Complain/>} />
        <Route path="/custzone/changepassword" element={<ChangePassword/>} />
        <Route path="/custzone/logout" element={<Logout/>} />
        <Route path="/adminzone/adminhome" element={<AdminHome/>} />
        <Route path="/adminzone/customers" element={<Customers/>} />
        <Route path="/adminzone/feedbacks" element={<Feedbacks/>} />
        <Route path="/adminzone/complains" element={<Complains/>} />
        <Route path="/adminzone/enquiries" element={<Enquiries/>} />
        <Route path="/adminzone/adminchangepassword" element={<AdminChangePassword/>} />
        <Route path="/adminzone/adminlogout" element={<AdminLogout/>} />
      </Routes>
      {/* <Footer /> */}
    </>
  );
}

export default App;
