import { Link, } from "react-router-dom";
import logo from "./../IMG/logo.jpg";
import LoginIcon from '@mui/icons-material/Login';
import "./Footer.css";
const Header = () => {
  return (
    <>
      <nav className="navbar navbar-expand-lg navbar-dark  heade" style={{background:'#2c4c54',boxShadow: '0 2px 15px -2px rgba(0,0,0,0.5)',borderRadius:'0px 0px 20px 20px'}}>
        <div className="container-fluid ">
        <img
            src={logo}
            className="d-block "
            width="70px"
            height="60px"
            alt="..."
          />
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active" to="/">Home </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/about">
                  About Us
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active " to="/registration">
                Registration
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/contact">
                  Contact Us
                </Link>
              </li>
              <li className="nav-item d-flex shado" style={{width:'100px', height:'40px',backgroundColor:'#43e6b2',textAlign:'center',boxShadow: '5px 5px 5px 0px rgba(0,0,0,0.3)'}}>
                <Link className="nav-link active " to="/login">
                  <LoginIcon /> Login
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </>
  );
};
export default Header;
