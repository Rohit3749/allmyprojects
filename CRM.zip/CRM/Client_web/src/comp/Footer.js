import React from 'react'
import { Link } from "react-router-dom";
import logo from "./../IMG/logo.jpg";
import "./Footer.css";

function Footer() {
  return (
    <>
    <footer>
      <div class="footer">
        <div class="container-fluid">
          <div class="row">
            <div class="footer-col">
            <img
            src={logo}
            className="d-block "
            width="60px"
            height="40px"
            alt="..."
            style={{marginLeft:'35px',borderRadius:'5px',marginBottom:'20px'}}
          />
              <ul>
                <li>
                <Link  to="/">Home </Link>
                </li>
                <li>
                <Link to="/about">
                  About Us
                </Link>
                </li>
                <li>
                  <a href="#">Term & Condation</a>
                </li>
                <li>
                <Link to="/contact">
                  Contact Us
                </Link>
                </li>
              </ul>
            </div>
            <div class="footer-col">
              <h4>Serviecs</h4>
              <ul>
                <li>
                  <a href="#">R & D</a>
                </li>
                <li>
                  <a href="#">MARC Hospitals</a>
                </li>
                <li>
                  <a href="#">Medicine Journal</a>
                </li>
                <li>
                  <a href="#">FQX</a>
                </li>
                <li>
                  <a href="#">MARC Med Skills</a>
                </li>
              </ul>
            </div>
            <div class="footer-col">
              <h4>Get In Tuch</h4>
              <ul>
                <li>
                  <a href="#">Term & Condation</a>
                </li>
                <li>
                  <a href="#">Link</a>
                </li>
                <li>
                  <a href="#">Registration</a>
                </li>
                <li>
                  <a href="#">Content Us</a>
                </li>
              </ul>
            </div>
            <div class="footer-col">
              <h4>Popular Cities</h4>
              <ul>
                <li>
                  <a href="#">New Delhi</a>
                </li>
                <li>
                  <a href="#">Mumbai</a>
                </li>
                <li>
                  <a href="#">Noida</a>
                </li>
                <li>
                  <a href="#">Kolkata</a>
                </li>
              </ul>
            </div>
            <div class="footer-col">
              <h4 style={{fontSize:'20px'}}>REGISTERED OFFICE</h4>
              <ul>
                <li>
                  <a href="#"> MARC Pharma Ltd</a>
                </li>
                <li>
                  <a href="#">Plot no.2, Mahaneger </a>
                </li>
                <li>
                  <a href="#">Lucknow (220022) India</a>
                </li>
                <li>
                  <a href="#">Fax: +91-11-2222-4444</a>
                </li>
                <li>
                  <a href="#">Email:info@marc.com</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </>
  )
}

export default Footer;