import React, {useState, useEffect} from 'react'
import axios from 'axios'
import Marquee from 'react-fast-marquee';

export default function Notifi() {
    const [data,setData]=useState([]);
    const loadData=async()=>{
        const response=await axios.get("http://localhost:5000/viewns");
        setData(response.data);
    }
    useEffect(()=>{
        loadData();
    },[]);
  return (
    <div className='mt-2 text-center py-4' style={{height:"auto",background: "radial-gradient(circle, rgba(251,63,161,1) -4%, rgba(70,252,201,1) 97%)"}}>
    <Marquee pauseOnHover={true} speed="90" >
    <table className='w-75'>
        <thead>
            <tr>
                <th>Notification</th>
                <th>Posted Date</th>
            </tr>
        </thead>
        <tbody>
            {
                data.map((value,index)=>{
                    return(
                        <tr key={value.id}>
                            <td>{value.notificationtext	}</td>
                            <td>{value.posteddate}</td>
                        </tr>
                    )
                })
            }
        </tbody>
    </table>
    </Marquee>
</div>

     )
}
