import React from 'react'
import Footer from './Footer'
import Header from './Header'
import { Toaster } from 'react-hot-toast';


export default function Layout(props) {
  return (
    <div>
    <Header/>
    
{props.children}
<Toaster/>
<Footer/>
    </div>
  )
}
